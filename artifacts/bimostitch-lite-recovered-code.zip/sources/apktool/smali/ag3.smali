.class public final Lag3;
.super Ljava/lang/Object;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:[Ljava/lang/Class;


# direct methods
.method public varargs constructor <init>(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lag3;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Lag3;->b:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Lag3;->c:[Ljava/lang/Class;

    .line 9
    .line 10
    return-void
.end method
