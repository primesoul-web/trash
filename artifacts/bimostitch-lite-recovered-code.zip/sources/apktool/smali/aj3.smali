.class public abstract Laj3;
.super Lqr1;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"

# interfaces
.implements Lbj3;


# static fields
.field public static final synthetic h:I
