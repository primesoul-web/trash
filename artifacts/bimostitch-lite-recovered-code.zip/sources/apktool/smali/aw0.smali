.class public interface abstract Law0;
.super Ljava/lang/Object;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"

# interfaces
.implements Lh40;


# virtual methods
.method public abstract a(Landroid/content/Context;Lal0;II)Lal0;
.end method
