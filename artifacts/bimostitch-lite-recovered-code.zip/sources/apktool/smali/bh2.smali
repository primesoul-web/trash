.class public final Lbh2;
.super Ljava/lang/Object;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"


# static fields
.field public static final A:Ljava/lang/String;

.field public static final B:Ljava/lang/String;

.field public static final C:Ljava/lang/String;

.field public static final D:Ljava/lang/String;

.field public static final E:Ljava/lang/String;

.field public static final F:Ljava/lang/String;

.field public static final G:Ljava/lang/String;

.field public static final H:Ljava/lang/String;

.field public static final I:Ljava/lang/String;

.field public static final q:Ljava/lang/String;

.field public static final r:Ljava/lang/String;

.field public static final s:Ljava/lang/String;

.field public static final t:Ljava/lang/String;

.field public static final u:Ljava/lang/String;

.field public static final v:Ljava/lang/String;

.field public static final w:Ljava/lang/String;

.field public static final x:Ljava/lang/String;

.field public static final y:Ljava/lang/String;

.field public static final z:Ljava/lang/String;


# instance fields
.field public final a:Ljava/lang/CharSequence;

.field public final b:Landroid/text/Layout$Alignment;

.field public final c:Landroid/text/Layout$Alignment;

.field public final d:Landroid/graphics/Bitmap;

.field public final e:F

.field public final f:I

.field public final g:I

.field public final h:F

.field public final i:I

.field public final j:F

.field public final k:F

.field public final l:I

.field public final m:F

.field public final n:I

.field public final o:F

.field public final p:I


# direct methods
.method static constructor <clinit>()V
    .locals 17

    .line 1
    const/4 v4, 0x0

    .line 2
    new-instance v0, Lbh2;

    .line 3
    .line 4
    const-string v1, ""

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    const v5, -0x800001

    .line 8
    .line 9
    .line 10
    const/high16 v6, -0x80000000

    .line 11
    .line 12
    const/4 v15, 0x0

    .line 13
    const/16 v16, 0x0

    .line 14
    .line 15
    move-object v3, v2

    .line 16
    move v7, v6

    .line 17
    move v8, v5

    .line 18
    move v9, v6

    .line 19
    move v10, v6

    .line 20
    move v11, v5

    .line 21
    move v12, v5

    .line 22
    move v13, v5

    .line 23
    move v14, v6

    .line 24
    invoke-direct/range {v0 .. v16}, Lbh2;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFIFI)V

    .line 25
    .line 26
    .line 27
    sget-object v0, Lr53;->a:Ljava/lang/String;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    const/16 v1, 0x24

    .line 31
    .line 32
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    sput-object v0, Lbh2;->q:Ljava/lang/String;

    .line 37
    .line 38
    const/16 v0, 0x11

    .line 39
    .line 40
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    sput-object v0, Lbh2;->r:Ljava/lang/String;

    .line 45
    .line 46
    const/4 v0, 0x1

    .line 47
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    sput-object v0, Lbh2;->s:Ljava/lang/String;

    .line 52
    .line 53
    const/4 v0, 0x2

    .line 54
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    sput-object v0, Lbh2;->t:Ljava/lang/String;

    .line 59
    .line 60
    const/4 v0, 0x3

    .line 61
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    const/16 v0, 0x12

    .line 65
    .line 66
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    sput-object v0, Lbh2;->u:Ljava/lang/String;

    .line 71
    .line 72
    const/4 v0, 0x4

    .line 73
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    sput-object v0, Lbh2;->v:Ljava/lang/String;

    .line 78
    .line 79
    const/4 v0, 0x5

    .line 80
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    sput-object v0, Lbh2;->w:Ljava/lang/String;

    .line 85
    .line 86
    const/4 v0, 0x6

    .line 87
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    sput-object v0, Lbh2;->x:Ljava/lang/String;

    .line 92
    .line 93
    const/4 v0, 0x7

    .line 94
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    sput-object v0, Lbh2;->y:Ljava/lang/String;

    .line 99
    .line 100
    const/16 v0, 0x8

    .line 101
    .line 102
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    sput-object v0, Lbh2;->z:Ljava/lang/String;

    .line 107
    .line 108
    const/16 v0, 0x9

    .line 109
    .line 110
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    sput-object v0, Lbh2;->A:Ljava/lang/String;

    .line 115
    .line 116
    const/16 v0, 0xa

    .line 117
    .line 118
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    sput-object v0, Lbh2;->B:Ljava/lang/String;

    .line 123
    .line 124
    const/16 v0, 0xb

    .line 125
    .line 126
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    sput-object v0, Lbh2;->C:Ljava/lang/String;

    .line 131
    .line 132
    const/16 v0, 0xc

    .line 133
    .line 134
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    sput-object v0, Lbh2;->D:Ljava/lang/String;

    .line 139
    .line 140
    const/16 v0, 0xd

    .line 141
    .line 142
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    sput-object v0, Lbh2;->E:Ljava/lang/String;

    .line 147
    .line 148
    const/16 v0, 0xe

    .line 149
    .line 150
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    sput-object v0, Lbh2;->F:Ljava/lang/String;

    .line 155
    .line 156
    const/16 v0, 0xf

    .line 157
    .line 158
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    sput-object v0, Lbh2;->G:Ljava/lang/String;

    .line 163
    .line 164
    const/16 v0, 0x10

    .line 165
    .line 166
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    sput-object v0, Lbh2;->H:Ljava/lang/String;

    .line 171
    .line 172
    const/16 v0, 0x13

    .line 173
    .line 174
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    sput-object v0, Lbh2;->I:Ljava/lang/String;

    .line 179
    .line 180
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFIFI)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    goto :goto_1

    .line 10
    :cond_0
    if-nez p4, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_1
    const/4 v0, 0x0

    .line 15
    :goto_0
    invoke-static {v0}, Lmz;->G(Z)V

    .line 16
    .line 17
    .line 18
    :goto_1
    instance-of v0, p1, Landroid/text/Spanned;

    .line 19
    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    invoke-static {p1}, Landroid/text/SpannedString;->valueOf(Ljava/lang/CharSequence;)Landroid/text/SpannedString;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    iput-object p1, p0, Lbh2;->a:Ljava/lang/CharSequence;

    .line 27
    .line 28
    goto :goto_3

    .line 29
    :cond_2
    if-eqz p1, :cond_3

    .line 30
    .line 31
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    :goto_2
    iput-object p1, p0, Lbh2;->a:Ljava/lang/CharSequence;

    .line 36
    .line 37
    goto :goto_3

    .line 38
    :cond_3
    const/4 p1, 0x0

    .line 39
    goto :goto_2

    .line 40
    :goto_3
    iput-object p2, p0, Lbh2;->b:Landroid/text/Layout$Alignment;

    .line 41
    .line 42
    iput-object p3, p0, Lbh2;->c:Landroid/text/Layout$Alignment;

    .line 43
    .line 44
    iput-object p4, p0, Lbh2;->d:Landroid/graphics/Bitmap;

    .line 45
    .line 46
    iput p5, p0, Lbh2;->e:F

    .line 47
    .line 48
    iput p6, p0, Lbh2;->f:I

    .line 49
    .line 50
    iput p7, p0, Lbh2;->g:I

    .line 51
    .line 52
    iput p8, p0, Lbh2;->h:F

    .line 53
    .line 54
    iput p9, p0, Lbh2;->i:I

    .line 55
    .line 56
    iput p12, p0, Lbh2;->j:F

    .line 57
    .line 58
    iput p13, p0, Lbh2;->k:F

    .line 59
    .line 60
    iput p10, p0, Lbh2;->l:I

    .line 61
    .line 62
    iput p11, p0, Lbh2;->m:F

    .line 63
    .line 64
    iput p14, p0, Lbh2;->n:I

    .line 65
    .line 66
    move/from16 p1, p15

    .line 67
    .line 68
    iput p1, p0, Lbh2;->o:F

    .line 69
    .line 70
    move/from16 p1, p16

    .line 71
    .line 72
    iput p1, p0, Lbh2;->p:I

    .line 73
    .line 74
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto/16 :goto_1

    .line 4
    .line 5
    :cond_0
    if-eqz p1, :cond_4

    .line 6
    .line 7
    const-class v0, Lbh2;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-eq v0, v1, :cond_1

    .line 14
    .line 15
    goto/16 :goto_2

    .line 16
    .line 17
    :cond_1
    check-cast p1, Lbh2;

    .line 18
    .line 19
    iget-object v0, p0, Lbh2;->a:Ljava/lang/CharSequence;

    .line 20
    .line 21
    iget-object v1, p1, Lbh2;->a:Ljava/lang/CharSequence;

    .line 22
    .line 23
    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    iget-object v0, p0, Lbh2;->b:Landroid/text/Layout$Alignment;

    .line 30
    .line 31
    iget-object v1, p1, Lbh2;->b:Landroid/text/Layout$Alignment;

    .line 32
    .line 33
    if-ne v0, v1, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lbh2;->c:Landroid/text/Layout$Alignment;

    .line 36
    .line 37
    iget-object v1, p1, Lbh2;->c:Landroid/text/Layout$Alignment;

    .line 38
    .line 39
    if-ne v0, v1, :cond_4

    .line 40
    .line 41
    iget-object v0, p1, Lbh2;->d:Landroid/graphics/Bitmap;

    .line 42
    .line 43
    iget-object v1, p0, Lbh2;->d:Landroid/graphics/Bitmap;

    .line 44
    .line 45
    if-nez v1, :cond_2

    .line 46
    .line 47
    if-nez v0, :cond_4

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    if-eqz v0, :cond_4

    .line 51
    .line 52
    invoke-virtual {v1, v0}, Landroid/graphics/Bitmap;->sameAs(Landroid/graphics/Bitmap;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_3

    .line 57
    .line 58
    goto :goto_2

    .line 59
    :cond_3
    :goto_0
    iget v0, p0, Lbh2;->e:F

    .line 60
    .line 61
    iget v1, p1, Lbh2;->e:F

    .line 62
    .line 63
    cmpl-float v0, v0, v1

    .line 64
    .line 65
    if-nez v0, :cond_4

    .line 66
    .line 67
    iget v0, p0, Lbh2;->f:I

    .line 68
    .line 69
    iget v1, p1, Lbh2;->f:I

    .line 70
    .line 71
    if-ne v0, v1, :cond_4

    .line 72
    .line 73
    iget v0, p0, Lbh2;->g:I

    .line 74
    .line 75
    iget v1, p1, Lbh2;->g:I

    .line 76
    .line 77
    if-ne v0, v1, :cond_4

    .line 78
    .line 79
    iget v0, p0, Lbh2;->h:F

    .line 80
    .line 81
    iget v1, p1, Lbh2;->h:F

    .line 82
    .line 83
    cmpl-float v0, v0, v1

    .line 84
    .line 85
    if-nez v0, :cond_4

    .line 86
    .line 87
    iget v0, p0, Lbh2;->i:I

    .line 88
    .line 89
    iget v1, p1, Lbh2;->i:I

    .line 90
    .line 91
    if-ne v0, v1, :cond_4

    .line 92
    .line 93
    iget v0, p0, Lbh2;->j:F

    .line 94
    .line 95
    iget v1, p1, Lbh2;->j:F

    .line 96
    .line 97
    cmpl-float v0, v0, v1

    .line 98
    .line 99
    if-nez v0, :cond_4

    .line 100
    .line 101
    iget v0, p0, Lbh2;->k:F

    .line 102
    .line 103
    iget v1, p1, Lbh2;->k:F

    .line 104
    .line 105
    cmpl-float v0, v0, v1

    .line 106
    .line 107
    if-nez v0, :cond_4

    .line 108
    .line 109
    iget v0, p0, Lbh2;->l:I

    .line 110
    .line 111
    iget v1, p1, Lbh2;->l:I

    .line 112
    .line 113
    if-ne v0, v1, :cond_4

    .line 114
    .line 115
    iget v0, p0, Lbh2;->m:F

    .line 116
    .line 117
    iget v1, p1, Lbh2;->m:F

    .line 118
    .line 119
    cmpl-float v0, v0, v1

    .line 120
    .line 121
    if-nez v0, :cond_4

    .line 122
    .line 123
    iget v0, p0, Lbh2;->n:I

    .line 124
    .line 125
    iget v1, p1, Lbh2;->n:I

    .line 126
    .line 127
    if-ne v0, v1, :cond_4

    .line 128
    .line 129
    iget v0, p0, Lbh2;->o:F

    .line 130
    .line 131
    iget v1, p1, Lbh2;->o:F

    .line 132
    .line 133
    cmpl-float v0, v0, v1

    .line 134
    .line 135
    if-nez v0, :cond_4

    .line 136
    .line 137
    iget p0, p0, Lbh2;->p:I

    .line 138
    .line 139
    iget p1, p1, Lbh2;->p:I

    .line 140
    .line 141
    if-ne p0, p1, :cond_4

    .line 142
    .line 143
    :goto_1
    const/4 p0, 0x1

    .line 144
    return p0

    .line 145
    :cond_4
    :goto_2
    const/4 p0, 0x0

    .line 146
    return p0
.end method

.method public final hashCode()I
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lbh2;->e:F

    .line 4
    .line 5
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    iget v2, v0, Lbh2;->f:I

    .line 10
    .line 11
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    iget v3, v0, Lbh2;->g:I

    .line 16
    .line 17
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    iget v4, v0, Lbh2;->h:F

    .line 22
    .line 23
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    iget v5, v0, Lbh2;->i:I

    .line 28
    .line 29
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    iget v6, v0, Lbh2;->j:F

    .line 34
    .line 35
    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    iget v7, v0, Lbh2;->k:F

    .line 40
    .line 41
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 42
    .line 43
    .line 44
    move-result-object v7

    .line 45
    const/high16 v8, -0x1000000

    .line 46
    .line 47
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 48
    .line 49
    .line 50
    move-result-object v8

    .line 51
    iget v9, v0, Lbh2;->l:I

    .line 52
    .line 53
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v9

    .line 57
    iget v10, v0, Lbh2;->m:F

    .line 58
    .line 59
    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 60
    .line 61
    .line 62
    move-result-object v10

    .line 63
    iget v11, v0, Lbh2;->n:I

    .line 64
    .line 65
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v11

    .line 69
    iget v12, v0, Lbh2;->o:F

    .line 70
    .line 71
    invoke-static {v12}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 72
    .line 73
    .line 74
    move-result-object v12

    .line 75
    iget v13, v0, Lbh2;->p:I

    .line 76
    .line 77
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object v13

    .line 81
    const/16 v14, 0x12

    .line 82
    .line 83
    new-array v14, v14, [Ljava/lang/Object;

    .line 84
    .line 85
    const/16 v16, 0x0

    .line 86
    .line 87
    iget-object v15, v0, Lbh2;->a:Ljava/lang/CharSequence;

    .line 88
    .line 89
    aput-object v15, v14, v16

    .line 90
    .line 91
    const/16 v16, 0x1

    .line 92
    .line 93
    iget-object v15, v0, Lbh2;->b:Landroid/text/Layout$Alignment;

    .line 94
    .line 95
    aput-object v15, v14, v16

    .line 96
    .line 97
    const/16 v16, 0x2

    .line 98
    .line 99
    iget-object v15, v0, Lbh2;->c:Landroid/text/Layout$Alignment;

    .line 100
    .line 101
    aput-object v15, v14, v16

    .line 102
    .line 103
    const/4 v15, 0x3

    .line 104
    iget-object v0, v0, Lbh2;->d:Landroid/graphics/Bitmap;

    .line 105
    .line 106
    aput-object v0, v14, v15

    .line 107
    .line 108
    const/4 v0, 0x4

    .line 109
    aput-object v1, v14, v0

    .line 110
    .line 111
    const/4 v0, 0x5

    .line 112
    aput-object v2, v14, v0

    .line 113
    .line 114
    const/4 v0, 0x6

    .line 115
    aput-object v3, v14, v0

    .line 116
    .line 117
    const/4 v0, 0x7

    .line 118
    aput-object v4, v14, v0

    .line 119
    .line 120
    const/16 v0, 0x8

    .line 121
    .line 122
    aput-object v5, v14, v0

    .line 123
    .line 124
    const/16 v0, 0x9

    .line 125
    .line 126
    aput-object v6, v14, v0

    .line 127
    .line 128
    const/16 v0, 0xa

    .line 129
    .line 130
    aput-object v7, v14, v0

    .line 131
    .line 132
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 133
    .line 134
    const/16 v1, 0xb

    .line 135
    .line 136
    aput-object v0, v14, v1

    .line 137
    .line 138
    const/16 v0, 0xc

    .line 139
    .line 140
    aput-object v8, v14, v0

    .line 141
    .line 142
    const/16 v0, 0xd

    .line 143
    .line 144
    aput-object v9, v14, v0

    .line 145
    .line 146
    const/16 v0, 0xe

    .line 147
    .line 148
    aput-object v10, v14, v0

    .line 149
    .line 150
    const/16 v0, 0xf

    .line 151
    .line 152
    aput-object v11, v14, v0

    .line 153
    .line 154
    const/16 v0, 0x10

    .line 155
    .line 156
    aput-object v12, v14, v0

    .line 157
    .line 158
    const/16 v0, 0x11

    .line 159
    .line 160
    aput-object v13, v14, v0

    .line 161
    .line 162
    invoke-static {v14}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    return v0
.end method
