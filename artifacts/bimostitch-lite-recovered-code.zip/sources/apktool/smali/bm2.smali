.class public interface abstract Lbm2;
.super Ljava/lang/Object;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"


# virtual methods
.method public abstract C()V
.end method

.method public abstract q()V
.end method
