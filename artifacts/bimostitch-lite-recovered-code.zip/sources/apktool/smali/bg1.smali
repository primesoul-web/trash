.class public interface abstract Lbg1;
.super Ljava/lang/Object;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b(J)Ljava/util/ArrayList;
.end method

.method public abstract u(I)J
.end method
