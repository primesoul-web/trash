.class public final Laf0;
.super Ljava/lang/Object;
.source "r8-map-id-feb309be28723916b74a2526b1508f8a1f09227099db017fc1624552251bc072"


# instance fields
.field public a:Ljava/util/UUID;

.field public b:Lo31;

.field public c:Ljava/util/HashSet;
