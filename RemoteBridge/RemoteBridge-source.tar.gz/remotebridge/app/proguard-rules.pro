# No specific ProGuard rules needed for this small app; OkHttp ships its own.
