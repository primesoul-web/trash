package com.remotebridge.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Auto-starts the foreground service after device boot, so the AVRCP
 * capture works without manually opening the app each time.
 *
 * Only starts the service if bridge mode is enabled (we don't want a
 * useless persistent notification if the user left it off).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val settings = SettingsRepository(context)
        if (settings.bridgeModeEnabled) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(
                        Intent(context, BridgeForegroundService::class.java)
                    )
                } else {
                    context.startService(
                        Intent(context, BridgeForegroundService::class.java)
                    )
                }
            } catch (_: Exception) {
                // Some OEMs block background starts right after boot until
                // the user unlocks. We'll retry next time the app is opened.
            }
        }
    }
}
