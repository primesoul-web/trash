package com.remotebridge.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.media.session.MediaButtonReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Foreground service that owns the active [MediaSessionCompat] used to capture
 * AVRCP media-button events from a connected Bluetooth speaker remote.
 *
 * When bridge mode is ON, button events are translated into HTTP POSTs to the
 * configured PC. When bridge mode is OFF, the session is set inactive and
 * releases audio focus so other apps' sessions take over the buttons.
 */
class BridgeForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var settings: SettingsRepository
    private lateinit var client: PcBridgeClient

    private var mediaSession: MediaSessionCompat? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    /** Debounce: ignore button repeats within this window (ms). */
    private val debounceMs = 300L
    private val lastEventLock = Mutex()
    private var lastEventTimestamps = mutableMapOf<String, Long>()

    // Bridge mode is read from settings on each event so the toggle takes
    // effect immediately without needing to restart the service.
    private fun isBridgeModeOn(): Boolean = settings.bridgeModeEnabled

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        client = PcBridgeClient(settings)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        setupMediaSession()
        Log.i(TAG, "Service created")
    }

    private fun setupMediaSession() {
        val session = MediaSessionCompat(this, "RemoteBridgeSession").apply {
            // We need a callback that handles the AVRCP transport controls.
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    handleButton("play_pause") { client.send(PcBridgeClient.Action.TOGGLE) }
                }

                override fun onPause() {
                    handleButton("play_pause") { client.send(PcBridgeClient.Action.TOGGLE) }
                }

                // Some remotes send onSkipToNext for the Next button.
                override fun onSkipToNext() {
                    handleButton("next") { client.send(PcBridgeClient.Action.FORWARD) }
                }

                override fun onSkipToPrevious() {
                    handleButton("prev") { client.send(PcBridgeClient.Action.BACK) }
                }

                // Some remotes send onFastForward / onRewind for long-press.
                override fun onFastForward() {
                    handleButton("next") { client.send(PcBridgeClient.Action.FORWARD) }
                }

                override fun onRewind() {
                    handleButton("prev") { client.send(PcBridgeClient.Action.BACK) }
                }

                // Stop button (some remotes): treat as toggle for safety.
                override fun onStop() {
                    handleButton("stop") { client.send(PcBridgeClient.Action.TOGGLE) }
                }
            })

            // Publish fake metadata so the system considers us a real media
            // source worth routing button events to. Without this, AVRCP may
            // not deliver events to us.
            setMetadata(
                MediaMetadataCompat.Builder()
                    .putString(MediaMetadataCompat.METADATA_KEY_TITLE, "RemoteBridge")
                    .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "PC Bridge")
                    .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, -1L)
                    .build()
            )

            // Set an initial "playing" state so the remote's transport buttons
            // light up and route to us. We only really act when bridge mode is on.
            setPlaybackState(buildPlaybackState(PlaybackStateCompat.STATE_PLAYING))

            isActive = true
        }
        mediaSession = session
    }

    private fun buildPlaybackState(state: Int): PlaybackStateCompat {
        val actions = (PlaybackStateCompat.ACTION_PLAY
                or PlaybackStateCompat.ACTION_PAUSE
                or PlaybackStateCompat.ACTION_PLAY_PAUSE
                or PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                or PlaybackStateCompat.ACTION_FAST_FORWARD
                or PlaybackStateCompat.ACTION_REWIND
                or PlaybackStateCompat.ACTION_STOP)
        return PlaybackStateCompat.Builder()
            .setActions(actions)
            .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1.0f)
            .build()
    }

    /**
     * Wraps every button callback with:
     * 1. Bridge-mode check (if off, do nothing — let the system route to next session).
     * 2. Debounce to filter rapid double-presses.
     * 3. HTTP request off the main thread, silent on failure.
     */
    private fun handleButton(key: String, action: () -> PcBridgeClient.Result) {
        if (!isBridgeModeOn()) {
            Log.d(TAG, "Button $key received but bridge mode is OFF — ignoring")
            return
        }
        scope.launch {
            val now = System.currentTimeMillis()
            val ok = lastEventLock.withLock {
                val last = lastEventTimestamps[key] ?: 0L
                if (now - last < debounceMs) {
                    false
                } else {
                    lastEventTimestamps[key] = now
                    true
                }
            }
            if (!ok) {
                Log.d(TAG, "Debounced duplicate $key press")
                return@launch
            }
            when (val r = action()) {
                is PcBridgeClient.Result.Success -> {
                    Log.i(TAG, "Sent $key to PC")
                    updateConnectionStatus(connected = true)
                }
                is PcBridgeClient.Result.Failure -> {
                    Log.w(TAG, "Failed to send $key: ${r.message}")
                    updateConnectionStatus(connected = false)
                }
            }
        }
    }

    private fun updateConnectionStatus(connected: Boolean) {
        // Refresh the notification to show a red/green dot.
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.notify(NOTIFICATION_ID, buildNotification(connected))
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .build()
            am.requestAudioFocus(req)
            audioFocusRequest = req
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand intent=${intent?.action}")

        // Start as foreground FIRST so we don't get killed before the
        // notification appears (Android may ANR / kill us otherwise).
        startForegroundCompat(buildNotification(connected = true))

        // Handle the quick-toggle action from the notification.
        if (intent?.action == ACTION_TOGGLE_MODE) {
            val newState = !settings.bridgeModeEnabled
            settings.bridgeModeEnabled = newState
            applyBridgeMode()
            updateConnectionStatus(connected = true) // refresh notification
        }

        // MediaButtonReceiver will hand MEDIA_BUTTON intents to the session.
        intent?.let { MediaButtonReceiver.handleIntent(mediaSession, it) }

        return START_STICKY
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /** Apply bridge-mode on/off: re-assert session + audio focus when on. */
    private fun applyBridgeMode() {
        val session = mediaSession ?: return
        if (settings.bridgeModeEnabled) {
            session.isActive = true
            requestAudioFocus()
            session.setPlaybackState(buildPlaybackState(PlaybackStateCompat.STATE_PLAYING))
        } else {
            session.setPlaybackState(buildPlaybackState(PlaybackStateCompat.STATE_PAUSED))
            session.isActive = false  // release so other apps' sessions take priority
            abandonAudioFocus()
        }
    }

    private fun buildNotification(connected: Boolean): Notification {
        val modeOn = settings.bridgeModeEnabled
        val modeText = if (modeOn) "PC Bridge Mode" else "Normal Mode"
        val statusText = if (modeOn) {
            if (connected) "Forwarding to ${settings.pcIp}:${settings.pcPort}"
            else "PC unreachable: ${settings.pcIp}:${settings.pcPort}"
        } else {
            "Buttons control phone media"
        }
        val smallIcon = if (modeOn) {
            if (connected) android.R.drawable.ic_media_play
            else android.R.drawable.ic_dialog_alert
        } else {
            android.R.drawable.ic_media_pause
        }

        // Open-app intent
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Quick-toggle intent
        val toggleIntent = Intent(this, BridgeForegroundService::class.java).apply {
            action = ACTION_TOGGLE_MODE
        }
        val togglePi = PendingIntent.getService(
            this, 1, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleLabel = if (modeOn) "Switch to Normal" else "Switch to Bridge"

        return NotificationCompat.Builder(this, getString(R.string.notification_channel_id))
            .setContentTitle("RemoteBridge — $modeText")
            .setContentText(statusText)
            .setSmallIcon(smallIcon)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_menu_sort_by_size, toggleLabel, togglePi)
            .build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Keep the service alive when the user swipes the task away.
        // START_STICKY will restart us if killed.
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy")
        try {
            mediaSession?.run {
                isActive = false
                release()
            }
            mediaSession = null
        } catch (t: Throwable) {
            Log.w(TAG, "Error releasing media session", t)
        }
        abandonAudioFocus()
        scope.cancel()
    }

    companion object {
        private const val TAG = "BridgeService"
        private const val NOTIFICATION_ID = 4242
        const val ACTION_TOGGLE_MODE = "com.remotebridge.app.action.TOGGLE_MODE"

        fun start(context: Context) {
            val intent = Intent(context, BridgeForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BridgeForegroundService::class.java))
        }
    }
}
