package com.remotebridge.app

import android.content.Context
import android.content.SharedPreferences

/**
 * Centralized access to persistent app settings backed by SharedPreferences.
 *
 * Holds the PC IP, port, and the current bridge mode. Wraps SharedPreferences
 * with a small Kotlin facade so the rest of the app can use typed accessors.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var pcIp: String
        get() = prefs.getString(KEY_PC_IP, DEFAULT_PC_IP) ?: DEFAULT_PC_IP
        set(value) = prefs.edit().putString(KEY_PC_IP, value.trim()).apply()

    var pcPort: Int
        get() = prefs.getInt(KEY_PC_PORT, DEFAULT_PC_PORT)
        set(value) = prefs.edit().putInt(KEY_PC_PORT, value.coerceIn(1, 65535)).apply()

    /** When true, the foreground service intercepts AVRCP button events. */
    var bridgeModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_BRIDGE_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_BRIDGE_MODE, value).apply()

    /** Whether the user has already seen the battery-optimization prompt. */
    var batteryPromptShown: Boolean
        get() = prefs.getBoolean(KEY_BATTERY_PROMPT, false)
        set(value) = prefs.edit().putBoolean(KEY_BATTERY_PROMPT, value).apply()

    fun baseUrl(): String = "http://$pcIp:$pcPort"

    companion object {
        private const val PREFS_NAME = "remote_bridge_prefs"
        private const val KEY_PC_IP = "pc_ip"
        private const val KEY_PC_PORT = "pc_port"
        private const val KEY_BRIDGE_MODE = "bridge_mode"
        private const val KEY_BATTERY_PROMPT = "battery_prompt_shown"

        const val DEFAULT_PC_IP = "192.168.1.100"
        const val DEFAULT_PC_PORT = 5005
    }
}
