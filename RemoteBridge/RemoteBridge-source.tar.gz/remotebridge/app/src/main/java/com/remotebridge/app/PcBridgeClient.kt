package com.remotebridge.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Tiny HTTP client that forwards media-button actions to the PC bridge server.
 *
 * All endpoints expect a POST with an empty body; the server returns 200 OK.
 * Timeouts are short (2s) so a dead PC doesn't hold the foreground service's
 * background thread hostage.
 */
class PcBridgeClient(
    private val settings: SettingsRepository,
) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .writeTimeout(TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    companion object {
        private const val TIMEOUT_MS = 2000L
    }

    enum class Action(val path: String) {
        TOGGLE("/toggle"),
        FORWARD("/forward"),
        BACK("/back"),
        SEEK_BACK("/seek?delta=-10"),  // optional: -10s
        SEEK_FORWARD("/seek?delta=10"), // optional: +10s
        PING("/ping")
    }

    sealed class Result {
        data object Success : Result()
        data class Failure(val message: String) : Result()
    }

    /** Sends an action; returns Success or Failure. Never throws. */
    fun send(action: Action): Result {
        return try {
            val url = "${settings.baseUrl()}${action.path}"
            val req = Request.Builder()
                .url(url)
                .post("".toRequestBody("text/plain".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) Result.Success
                else Result.Failure("HTTP ${resp.code}")
            }
        } catch (e: Exception) {
            Result.Failure(e.message ?: e.javaClass.simpleName)
        }
    }

    /** GET-style ping used by the "Test Connection" button. */
    fun ping(): Result {
        return try {
            val url = "${settings.baseUrl()}${Action.PING.path}"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) Result.Success
                else Result.Failure("HTTP ${resp.code}")
            }
        } catch (e: Exception) {
            Result.Failure(e.message ?: e.javaClass.simpleName)
        }
    }
}
