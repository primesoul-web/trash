package com.remotebridge.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Single-screen UI:
 *  - Big mode toggle (Normal / PC Bridge)
 *  - Status indicator (green dot / red dot)
 *  - PC IP + Port fields with persistent storage
 *  - Test Connection button
 *  - Manual control buttons (Play/Pause, -10s, +10s) as fallback
 *  - Battery-optimization exemption button
 */
class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* ignore result; we still try */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ensure the foreground service is running so we can capture AVRCP.
        BridgeForegroundService.start(this)

        // Ask for POST_NOTIFICATIONS on Android 13+.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // First-launch battery-optimization prompt.
        val settings = SettingsRepository(this)
        if (!settings.batteryPromptShown) {
            requestBatteryOptimizationExemption()
            settings.batteryPromptShown = true
        }

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BridgeAppScreen()
                }
            }
        }
    }

    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    // Some OEMs don't implement this intent; ignore.
                }
            }
        }
    }
}

@Composable
fun BridgeAppScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = remember { SettingsRepository(context) }
    val client = remember { PcBridgeClient(settings) }

    var pcIp by remember { mutableStateOf(settings.pcIp) }
    var pcPort by remember { mutableStateOf(settings.pcPort.toString()) }
    var bridgeMode by remember { mutableStateOf(settings.bridgeModeEnabled) }
    var statusText by remember { mutableStateOf("Idle") }
    var connected by remember { mutableStateOf<Boolean?>(null) } // null = unknown
    var testing by remember { mutableStateOf(false) }

    fun persistAll() {
        settings.pcIp = pcIp
        val port = pcPort.toIntOrNull() ?: SettingsRepository.DEFAULT_PC_PORT
        settings.pcPort = port
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF1E88E5))
            Text(
                "RemoteBridge",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E88E5)
            )
        }
        Text(
            "Bluetooth remote → PC bridge",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Status dot + text
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .background(
                        color = when (connected) {
                            true -> Color(0xFF4CAF50)
                            false -> Color(0xFFF44336)
                            null -> Color(0xFF9E9E9E)
                        },
                        shape = CircleShape
                    )
            )
            Text(statusText, fontSize = 14.sp)
        }

        Spacer(Modifier.height(8.dp))

        // Mode toggle — big and obvious, this is the main control.
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (bridgeMode) Color(0xFFE3F2FD) else Color(0xFFF5F5F5)
            )
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (bridgeMode) "PC Bridge Mode (ON)" else "Normal Mode (OFF)",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (bridgeMode)
                        "Remote button presses go to your PC via HTTP"
                    else
                        "Remote button presses control phone media as usual",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Switch(
                    checked = bridgeMode,
                    onCheckedChange = { newValue ->
                        bridgeMode = newValue
                        settings.bridgeModeEnabled = newValue
                        statusText = if (newValue) "Bridge mode active" else "Normal mode"
                        if (newValue) connected = null
                    },
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // PC settings card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFF1E88E5))
                    Spacer(Modifier.width(8.dp))
                    Text("PC Bridge Target", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedTextField(
                    value = pcIp,
                    onValueChange = { pcIp = it; persistAll() },
                    label = { Text("PC IP address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                OutlinedTextField(
                    value = pcPort,
                    onValueChange = {
                        pcPort = it.filter { c -> c.isDigit() }.take(5)
                        persistAll()
                    },
                    label = { Text("Port (default 5005)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            testing = true
                            statusText = "Testing connection…"
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { client.ping() }
                                testing = false
                                when (r) {
                                    is PcBridgeClient.Result.Success -> {
                                        connected = true
                                        statusText = "Connected (${settings.pcIp}:${settings.pcPort})"
                                    }
                                    is PcBridgeClient.Result.Failure -> {
                                        connected = false
                                        statusText = "Failed: ${r.message}"
                                    }
                                }
                            }
                        },
                        enabled = !testing
                    ) { Text(if (testing) "Testing…" else "Test Connection") }

                    OutlinedButton(onClick = {
                        // Open the battery-optimization settings screen for this app.
                        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        try {
                            context.startActivity(intent)
                        } catch (_: Exception) { /* ignore */ }
                    }) { Text("Battery…") }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Manual control buttons (fallback when remote doesn't work)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Manual controls (fallback)", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ManualButton("−10s") {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                client.send(PcBridgeClient.Action.SEEK_BACK)
                            }
                            applyResult(r, "−10s") { c, s -> connected = c; statusText = s }
                        }
                    }
                    ManualButton("Play/Pause") {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                client.send(PcBridgeClient.Action.TOGGLE)
                            }
                            applyResult(r, "Play/Pause") { c, s -> connected = c; statusText = s }
                        }
                    }
                    ManualButton("+10s") {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                client.send(PcBridgeClient.Action.SEEK_FORWARD)
                            }
                            applyResult(r, "+10s") { c, s -> connected = c; statusText = s }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ManualButton("Prev") {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                client.send(PcBridgeClient.Action.BACK)
                            }
                            applyResult(r, "Prev") { c, s -> connected = c; statusText = s }
                        }
                    }
                    ManualButton("Next") {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                client.send(PcBridgeClient.Action.FORWARD)
                            }
                            applyResult(r, "Next") { c, s -> connected = c; statusText = s }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) { Text(text) }
}

/**
 * Applies a manual-send result to the UI: sets the connection indicator +
 * status text. Lives outside the composable so the call sites stay compact.
 */
private fun applyResult(
    r: PcBridgeClient.Result,
    label: String,
    apply: (connected: Boolean, status: String) -> Unit
) {
    when (r) {
        is PcBridgeClient.Result.Success -> apply(true, "$label sent")
        is PcBridgeClient.Result.Failure -> apply(false, "$label failed: ${r.message}")
    }
}
