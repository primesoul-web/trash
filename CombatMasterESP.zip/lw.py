import win32gui, win32con

wins = []
def cb(h, extra):
    if win32gui.IsWindowVisible(h):
        t = win32gui.GetWindowText(h)
        r = win32gui.GetWindowRect(h)
        w = r[2] - r[0]
        h2 = r[3] - r[1]
        if w > 400 and h2 > 200 and t:
            wins.append((h, t, r, w, h2))

win32gui.EnumWindows(cb, None)
for h, t, r, w, h2 in sorted(wins, key=lambda x: -(x[3]*x[4])):
    print(f"{h:10d} | {w:5d}x{h2:5d} | pos=({r[0]},{r[1]}) | '{t}'")
