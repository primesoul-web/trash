@echo off
echo ============================================
echo   DIAGNOSTIC ESP (Run as Admin!)
echo ============================================
echo.
echo Make sure game is running and you're IN A MATCH!
echo Move around during the calibration phase.
echo.
cd /d D:\CombatMasterESP
python diag_esp.py
pause
