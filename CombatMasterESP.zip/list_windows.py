# list_windows.py – lists all visible top-level windows with their titles
import win32gui

def callback(hwnd, results):
    if win32gui.IsWindowVisible(hwnd):
        title = win32gui.GetWindowText(hwnd)
        rect  = win32gui.GetWindowRect(hwnd)
        w = rect[2] - rect[0]
        h = rect[3] - rect[1]
        if w > 100 and h > 100:  # only reasonably-sized windows
            results.append((hwnd, title, rect, w, h))

results = []
win32gui.EnumWindows(callback, results)

for hwnd, title, rect, w, h in sorted(results, key=lambda x: -x[3]*x[4]):
    print(f"hwnd={hwnd:8d}  size={w:5d}x{h:5d}  pos=({rect[0]},{rect[1]})  title='{title}'")
