# scan_entities_dynamic.py
import pymem
import struct
import time

def scan():
    try:
        pm = pymem.Pymem("CombatMaster.exe")
    except Exception as e:
        print(f"Error: {e}")
        return

    import ctypes
    from ctypes import wintypes
    
    class MEMORY_BASIC_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BaseAddress", ctypes.c_void_p),
            ("AllocationBase", ctypes.c_void_p),
            ("AllocationProtect", wintypes.DWORD),
            ("PartitionId", wintypes.WORD),
            ("RegionSize", ctypes.c_size_t),
            ("State", wintypes.DWORD),
            ("Protect", wintypes.DWORD),
            ("Type", wintypes.DWORD)
        ]
        
    kernel32 = ctypes.windll.kernel32
    VirtualQueryEx = kernel32.VirtualQueryEx
    handle = pm.process_handle
    
    print("Please MOVE in-game continuously so the scanner can locate your dynamic coordinates...")
    time.sleep(2)
    
    # Capture first state of heap memory
    print("Capturing state 1 of player structures...")
    state1 = {}
    address = 0
    mbi = MEMORY_BASIC_INFORMATION()
    while VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        if mbi.State == 0x1000 and mbi.Protect == 0x04 and mbi.Type == 0x20000:
            size = mbi.RegionSize
            if 32 * 1024 <= size <= 4 * 1024 * 1024:
                try:
                    chunk = pm.read_bytes(address, size)
                    state1[address] = chunk
                except:
                    pass
        address += mbi.RegionSize
        
    print("State 1 captured. Keep moving, waiting 3 seconds...")
    time.sleep(3)
    
    print("Capturing state 2 and analyzing variations...")
    address = 0
    matches = 0
    while VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        if mbi.State == 0x1000 and mbi.Protect == 0x04 and mbi.Type == 0x20000:
            size = mbi.RegionSize
            if address in state1 and 32 * 1024 <= size <= 4 * 1024 * 1024:
                try:
                    chunk1 = state1[address]
                    chunk2 = pm.read_bytes(address, size)
                    
                    float_len = size // 4
                    floats1 = struct.unpack(f"{float_len}f", chunk1[:float_len*4])
                    floats2 = struct.unpack(f"{float_len}f", chunk2[:float_len*4])
                    
                    for i in range(0, len(floats2) - 3, 4):
                        x1, y1, z1 = floats1[i], floats1[i+1], floats1[i+2]
                        x2, y2, z2 = floats2[i], floats2[i+1], floats2[i+2]
                        
                        # Check if coordinates are in typical game range
                        if -250.0 < x2 < 250.0 and -10.0 < y2 < 80.0 and -250.0 < z2 < 250.0:
                            # And check if the coordinates changed significantly between state 1 and 2
                            diff = abs(x2 - x1) + abs(y2 - y1) + abs(z2 - z1)
                            if 0.5 < diff < 100.0:
                                # Look for a health-like value (100) nearby
                                for offset in range(-32, 64, 4):
                                    idx = i + offset // 4
                                    if 0 <= idx < len(floats2):
                                        val_bytes = chunk2[idx*4 : idx*4+4]
                                        if len(val_bytes) == 4:
                                            val = int.from_bytes(val_bytes, byteorder='little')
                                            if 1 <= val <= 100:
                                                cand_addr = address + i * 4
                                                print(f"Dynamic Match: Addr={hex(cand_addr)} | Pos={x2:.2f},{y2:.2f},{z2:.2f} | Changed: {diff:.2f} | HP={val} at offset {offset}")
                                                matches += 1
                                                break
                                if matches >= 10:
                                    return
                except Exception as e:
                    pass
        address += mbi.RegionSize

if __name__ == "__main__":
    scan()
