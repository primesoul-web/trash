# main.py – Combat Master ESP (v4 – working, refined)
import sys, time, ctypes, struct, os
import pymem, pymem.process
from ctypes import wintypes
import tkinter as tk

EXE_NAME   = "CombatMaster.exe"
TARGET_FPS = 20

# ─── Memory helpers ──────────────────────────────────────────────────────────
class MBI(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD), ("PartitionId", wintypes.WORD),
        ("RegionSize", ctypes.c_size_t), ("State", wintypes.DWORD),
        ("Protect", wintypes.DWORD), ("Type", wintypes.DWORD),
    ]

_vqex = ctypes.windll.kernel32.VirtualQueryEx

def iter_rw(handle, max_sz=256*1024):
    mbi = MBI(); a = 0
    while _vqex(handle, ctypes.c_void_p(a), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        s = int(mbi.RegionSize)
        if (mbi.State == 0x1000 and mbi.Protect in (0x04, 0x40)
                and mbi.Type == 0x20000 and not (mbi.Protect & 0x100) and s <= max_sz):
            yield int(mbi.BaseAddress), s
        a += s

def iter_readable(handle):
    mbi = MBI(); a = 0
    while _vqex(handle, ctypes.c_void_p(a), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        s = int(mbi.RegionSize)
        if mbi.State == 0x1000 and (mbi.Protect & 0xEC) and not (mbi.Protect & 0x100):
            yield int(mbi.BaseAddress), s
        a += s

# ─── Matrix ──────────────────────────────────────────────────────────────────
def find_matrix(pm):
    h = pm.process_handle
    for base, size in iter_readable(h):
        if size < 64 or size > 128*1024*1024: continue
        try: chunk = pm.read_bytes(base, min(size, 4*1024*1024))
        except: continue
        for off in range(0, len(chunk) - 64, 4):
            v11, = struct.unpack_from("f", chunk, off + 44)
            if abs(v11 + 1.0) < 0.001:
                v15, = struct.unpack_from("f", chunk, off + 60)
                if abs(v15) < 0.001:
                    v0, = struct.unpack_from("f", chunk, off)
                    v5, = struct.unpack_from("f", chunk, off + 20)
                    if 0.3 < abs(v0) < 5.0 and 0.3 < abs(v5) < 5.0:
                        return base + off
    return None

def read_matrix(pm, addr):
    return list(struct.unpack("16f", pm.read_bytes(addr, 64)))

def verify_matrix(pm, addr):
    try:
        mf = struct.unpack("16f", pm.read_bytes(addr, 64))
        return abs(mf[11] + 1.0) < 0.01 and abs(mf[15]) < 0.01
    except: return False

# ─── W2S (row-major, confirmed working) ─────────────────────────────────────
def project(m, pos, sw, sh):
    x, y, z = pos
    cx = m[0]*x + m[1]*y + m[2]*z + m[3]
    cy = m[4]*x + m[5]*y + m[6]*z + m[7]
    cw = m[12]*x + m[13]*y + m[14]*z + m[15]
    if cw < 0.1: return 0, 0, False
    sx = int((cx/cw + 1.0) * 0.5 * sw)
    sy = int((1.0 - cy/cw) * 0.5 * sh)
    return sx, sy, (0 <= sx < sw and 0 <= sy < sh)

# ─── Entity finder (triple-snapshot + strict filter) ─────────────────────────
def snapshot(pm):
    snap = {}
    for base, size in iter_rw(pm.process_handle):
        try: chunk = pm.read_bytes(base, size)
        except: continue
        for off in range(0, len(chunk) - 12, 4):
            x, y, z = struct.unpack_from("3f", chunk, off)
            # STRICT: all 3 components must be non-trivial
            if abs(x) < 1.0 or abs(z) < 0.5:
                continue
            if not (-1500 < x < 1500 and -500 < y < 500 and -1500 < z < 1500):
                continue
            if x == y or y == z or x == z:
                continue
            snap[base + off] = (x, y, z)
    return snap

def find_entities(pm, delay=2.5):
    print("[1/3] Snapshot A …", flush=True)
    a = snapshot(pm)
    print(f"      {len(a)} candidates", flush=True)
    time.sleep(delay)
    print("[2/3] Snapshot B …", flush=True)
    b = snapshot(pm)
    print(f"      {len(b)} candidates", flush=True)
    time.sleep(delay)
    print("[3/3] Snapshot C …", flush=True)
    c = snapshot(pm)
    print(f"      {len(c)} candidates", flush=True)

    movers = []
    for addr in a:
        if addr not in b or addr not in c: continue
        xa,ya,za = a[addr]; xb,yb,zb = b[addr]; xc,yc,zc = c[addr]
        d_ab = ((xb-xa)**2+(yb-ya)**2+(zb-za)**2)**0.5
        d_bc = ((xc-xb)**2+(yc-yb)**2+(zc-zb)**2)**0.5
        if 0.05 < d_ab < 50 and 0.05 < d_bc < 50:
            movers.append((addr, xc, yc, zc))

    # Cluster nearby addresses
    movers.sort(key=lambda m: (round(m[1],0), round(m[3],0)))
    clusters = []; used = set()
    for i, (addr, x, y, z) in enumerate(movers):
        if i in used: continue
        used.add(i)
        best = (addr, x, y, z)
        for j in range(i+1, len(movers)):
            if j in used: continue
            _, x2, y2, z2 = movers[j]
            if abs(x-x2) < 3 and abs(y-y2) < 3 and abs(z-z2) < 3:
                used.add(j)
        clusters.append(best[0])

    print(f"[+] {len(movers)} movers → {len(clusters)} entities", flush=True)
    return clusters

# ─── Overlay ─────────────────────────────────────────────────────────────────
def make_overlay(sw, sh):
    os.environ['SDL_VIDEO_WINDOW_POS'] = "0,0"
    root = tk.Tk()
    root.geometry(f"{sw}x{sh}+0+0")
    root.overrideredirect(True)
    root.wm_attributes("-topmost", True)
    root.wm_attributes("-transparentcolor", "#010101")
    root.config(bg='#010101')
    canvas = tk.Canvas(root, width=sw, height=sh, bg='#010101',
                       highlightthickness=0, bd=0)
    canvas.pack()

    def keep_top():
        try:
            root.lift()
            root.wm_attributes("-topmost", True)
        except: pass
        root.after(2000, keep_top)
    keep_top()

    return root, canvas

# ─── Main ────────────────────────────────────────────────────────────────────
def main():
    print("=" * 50, flush=True)
    print("  Combat Master ESP v4", flush=True)
    print("=" * 50, flush=True)

    pm = pymem.Pymem(EXE_NAME)
    print(f"[+] Attached PID {pm.process_id}", flush=True)

    u32 = ctypes.windll.user32
    u32.SetProcessDPIAware()
    SW, SH = u32.GetSystemMetrics(0), u32.GetSystemMetrics(1)

    mat_addr = find_matrix(pm)
    if not mat_addr:
        print("[!] Matrix not found! Are you in a match?", flush=True)
        input("Press Enter to exit...")
        return
    print(f"[+] Matrix at {hex(mat_addr)}", flush=True)

    print("\n  MOVE AROUND IN GAME during calibration!\n", flush=True)
    entity_addrs = find_entities(pm)

    if not entity_addrs:
        print("[!] No entities found! Retrying with longer delay...", flush=True)
        entity_addrs = find_entities(pm, delay=4.0)

    root, canvas = make_overlay(SW, SH)

    recal_interval = 30.0
    last_recal = time.perf_counter()
    frame_time = 1.0 / TARGET_FPS

    print(f"[*] ESP running — {len(entity_addrs)} entities tracked", flush=True)
    print("[*] Press Ctrl+C or close window to quit.", flush=True)

    while True:
        t0 = time.perf_counter()
        try: root.update()
        except: break

        # Matrix check
        if not verify_matrix(pm, mat_addr):
            mat_addr = find_matrix(pm)
            if not mat_addr:
                time.sleep(1); continue

        matrix = read_matrix(pm, mat_addr)

        # Recalibrate entities
        now = time.perf_counter()
        if now - last_recal >= recal_interval:
            print("[*] Recalibrating …", flush=True)
            new = find_entities(pm, delay=2.0)
            if new:
                entity_addrs = new
                print(f"[+] Now tracking {len(entity_addrs)}", flush=True)
            last_recal = now

        # Draw
        canvas.delete("all")
        canvas.create_text(10, 15, text=f"ESP v4 | {len(entity_addrs)} tracked",
                          fill='#00ff00', font=('Arial', 13, 'bold'), anchor='w')

        drawn = 0
        for addr in entity_addrs:
            try:
                raw = pm.read_bytes(addr, 12)
                x, y, z = struct.unpack("3f", raw)
            except: continue

            if not (-1500 < x < 1500 and -500 < y < 500 and -1500 < z < 1500):
                continue
            if abs(x) < 1.0 or abs(z) < 0.5:
                continue

            sx, sy, on = project(matrix, (x, y, z), SW, SH)
            if not on: continue

            # Box
            bw, bh = 50, 90
            canvas.create_rectangle(sx-bw//2, sy-bh, sx+bw//2, sy,
                                   outline='#00ff00', width=2)
            # Coord label
            canvas.create_text(sx, sy-bh-4,
                              text=f"({x:.0f},{y:.0f},{z:.0f})",
                              fill='#ffff00', font=('Arial', 8), anchor='s')
            # Snapline
            canvas.create_line(SW//2, SH, sx, sy, fill='#ffff00', width=1)
            drawn += 1

        canvas.create_text(10, 35, text=f"{drawn} visible",
                          fill='#ff8800', font=('Arial', 11, 'bold'), anchor='w')

        root.update_idletasks()

        elapsed = time.perf_counter() - t0
        if frame_time - elapsed > 0:
            time.sleep(frame_time - elapsed)

    root.destroy()

if __name__ == "__main__":
    main()
