# diag_esp.py – Diagnostic ESP: strict 3-snapshot filter + projection debug
import sys, time, ctypes, struct
import pymem, pymem.process
from ctypes import wintypes
import tkinter as tk

EXE_NAME = "CombatMaster.exe"

# ─── Memory helpers ──────────────────────────────────────────────────────────
class MBI(ctypes.Structure):
    _fields_ = [
        ("BaseAddress",       ctypes.c_void_p),
        ("AllocationBase",    ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD),
        ("PartitionId",       wintypes.WORD),
        ("RegionSize",        ctypes.c_size_t),
        ("State",             wintypes.DWORD),
        ("Protect",           wintypes.DWORD),
        ("Type",              wintypes.DWORD),
    ]

_vqex = ctypes.windll.kernel32.VirtualQueryEx

def iter_rw(handle, max_sz=256*1024):
    mbi = MBI()
    a = 0
    while _vqex(handle, ctypes.c_void_p(a), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        s = int(mbi.RegionSize)
        if (mbi.State == 0x1000 and mbi.Protect in (0x04, 0x40)
                and mbi.Type == 0x20000 and not (mbi.Protect & 0x100)
                and s <= max_sz):
            yield int(mbi.BaseAddress), s
        a += s

# ─── Matrix finder ───────────────────────────────────────────────────────────
def find_matrix(pm):
    h = pm.process_handle
    mbi = MBI()
    a = 0
    while _vqex(h, ctypes.c_void_p(a), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        s = int(mbi.RegionSize)
        if mbi.State == 0x1000 and (mbi.Protect & 0xEC) and s >= 64 and s <= 128*1024*1024:
            try:
                chunk = pm.read_bytes(int(mbi.BaseAddress), min(s, 4*1024*1024))
            except: 
                a += s; continue
            for off in range(0, len(chunk) - 64, 4):
                v11, = struct.unpack_from("f", chunk, off + 44)
                if abs(v11 + 1.0) < 0.001:
                    v15, = struct.unpack_from("f", chunk, off + 60)
                    if abs(v15) < 0.001:
                        v0, = struct.unpack_from("f", chunk, off)
                        v5, = struct.unpack_from("f", chunk, off + 20)
                        if 0.3 < abs(v0) < 5.0 and 0.3 < abs(v5) < 5.0:
                            return int(mbi.BaseAddress) + off
        a += s
    return None

def read_matrix(pm, addr):
    raw = pm.read_bytes(addr, 64)
    return list(struct.unpack("16f", raw))

# ─── W2S projection ─────────────────────────────────────────────────────────
def project(matrix, pos, sw, sh):
    """Project 3D pos to screen (x, y, on_screen) using 4x4 VP matrix."""
    x, y, z = pos
    # Multiply: clip = matrix * [x, y, z, 1]
    # Try row-major (m[row*4 + col])
    m = matrix
    cx = m[0]*x + m[1]*y + m[2]*z + m[3]
    cy = m[4]*x + m[5]*y + m[6]*z + m[7]
    cz = m[8]*x + m[9]*y + m[10]*z + m[11]
    cw = m[12]*x + m[13]*y + m[14]*z + m[15]
    
    if cw < 0.1:
        return 0, 0, False
    
    ndx = cx / cw
    ndy = cy / cw
    
    sx = int((ndx + 1.0) * 0.5 * sw)
    sy = int((1.0 - ndy) * 0.5 * sh)
    
    on = 0 <= sx < sw and 0 <= sy < sh
    return sx, sy, on

def project_col(matrix, pos, sw, sh):
    """Try column-major convention instead."""
    x, y, z = pos
    m = matrix
    cx = m[0]*x + m[4]*y + m[8]*z  + m[12]
    cy = m[1]*x + m[5]*y + m[9]*z  + m[13]
    cz = m[2]*x + m[6]*y + m[10]*z + m[14]
    cw = m[3]*x + m[7]*y + m[11]*z + m[15]
    
    if cw < 0.1:
        return 0, 0, False
    
    ndx = cx / cw
    ndy = cy / cw
    
    sx = int((ndx + 1.0) * 0.5 * sw)
    sy = int((1.0 - ndy) * 0.5 * sh)
    
    on = 0 <= sx < sw and 0 <= sy < sh
    return sx, sy, on

# ─── Triple-snapshot entity finder ───────────────────────────────────────────
def snapshot(pm):
    h = pm.process_handle
    snap = {}
    for base, size in iter_rw(h):
        try:
            chunk = pm.read_bytes(base, size)
        except: continue
        for off in range(0, len(chunk) - 12, 4):
            x, y, z = struct.unpack_from("3f", chunk, off)
            if not (-1500 < x < 1500 and -500 < y < 500 and -1500 < z < 1500):
                continue
            if abs(x) < 0.5 and abs(z) < 0.5:
                continue
            if x == y == z:
                continue
            snap[base + off] = (x, y, z)
    return snap

def find_entities(pm):
    """Triple snapshot: keep only addresses that moved consistently."""
    print("[1/3] Snapshot A …", flush=True)
    a = snapshot(pm)
    print(f"      {len(a)} candidates", flush=True)
    
    time.sleep(2.0)
    print("[2/3] Snapshot B …", flush=True)
    b = snapshot(pm)
    print(f"      {len(b)} candidates", flush=True)
    
    time.sleep(2.0)
    print("[3/3] Snapshot C …", flush=True)
    c = snapshot(pm)
    print(f"      {len(c)} candidates", flush=True)
    
    # Keep addresses present in all 3 that moved A→B AND B→C
    movers = []
    for addr in a:
        if addr not in b or addr not in c:
            continue
        xa, ya, za = a[addr]
        xb, yb, zb = b[addr]
        xc, yc, zc = c[addr]
        
        d_ab = ((xb-xa)**2 + (yb-ya)**2 + (zb-za)**2) ** 0.5
        d_bc = ((xc-xb)**2 + (yc-yb)**2 + (zc-zb)**2) ** 0.5
        
        # Must have moved in both intervals (0.05 to 50 units)
        if 0.05 < d_ab < 50 and 0.05 < d_bc < 50:
            movers.append((addr, xc, yc, zc))
    
    # Cluster: group addresses within 3 units of each other, pick one per cluster
    movers.sort(key=lambda m: (round(m[1],0), round(m[3],0)))
    clusters = []
    used = set()
    for i, (addr, x, y, z) in enumerate(movers):
        if i in used:
            continue
        cluster = [(addr, x, y, z)]
        used.add(i)
        for j in range(i+1, len(movers)):
            if j in used:
                continue
            _, x2, y2, z2 = movers[j]
            if abs(x-x2) < 3 and abs(y-y2) < 3 and abs(z-z2) < 3:
                cluster.append(movers[j])
                used.add(j)
        # Use the first address in the cluster
        clusters.append(cluster[0])
    
    print(f"[+] {len(movers)} movers → {len(clusters)} unique entities", flush=True)
    return clusters

# ─── Main ────────────────────────────────────────────────────────────────────
def main():
    print("=" * 50)
    print("  DIAGNOSTIC ESP")
    print("=" * 50)
    
    pm = pymem.Pymem(EXE_NAME)
    print(f"[+] Attached PID {pm.process_id}", flush=True)
    
    # Screen
    u32 = ctypes.windll.user32
    u32.SetProcessDPIAware()
    SW = u32.GetSystemMetrics(0)
    SH = u32.GetSystemMetrics(1)
    
    # Matrix
    mat_addr = find_matrix(pm)
    if not mat_addr:
        print("[!] No matrix found!", flush=True)
        return
    print(f"[+] Matrix at {hex(mat_addr)}", flush=True)
    
    matrix = read_matrix(pm, mat_addr)
    print(f"    m[0]={matrix[0]:.3f} m[5]={matrix[5]:.3f} m[11]={matrix[11]:.3f} m[15]={matrix[15]:.3f}", flush=True)
    
    # Entities
    print("\n--- MOVE AROUND IN GAME! ---\n", flush=True)
    entities = find_entities(pm)
    
    if not entities:
        print("[!] No entities found!", flush=True)
        return
    
    # Print projection debug for first 10 entities using both conventions
    print(f"\n--- Projection debug (first 10 of {len(entities)}) ---", flush=True)
    matrix = read_matrix(pm, mat_addr)
    for addr, x, y, z in entities[:10]:
        sx_r, sy_r, on_r = project(matrix, (x,y,z), SW, SH)
        sx_c, sy_c, on_c = project_col(matrix, (x,y,z), SW, SH)
        print(f"  pos=({x:.1f},{y:.1f},{z:.1f}) "
              f"row→({sx_r},{sy_r},{'ON' if on_r else 'off'}) "
              f"col→({sx_c},{sy_c},{'ON' if on_c else 'off'})", flush=True)
    
    # Create overlay
    import os
    os.environ['SDL_VIDEO_WINDOW_POS'] = "0,0"
    
    root = tk.Tk()
    root.geometry(f"{SW}x{SH}+0+0")
    root.overrideredirect(True)
    root.wm_attributes("-topmost", True)
    root.wm_attributes("-transparentcolor", "#010101")
    root.config(bg='#010101')
    canvas = tk.Canvas(root, width=SW, height=SH, bg='#010101',
                       highlightthickness=0, bd=0)
    canvas.pack()
    
    entity_addrs = [e[0] for e in entities]
    
    print(f"\n[*] Drawing overlay … {len(entity_addrs)} entities", flush=True)
    
    # Determine which projection to use based on which gives more on-screen results
    use_col = False
    matrix = read_matrix(pm, mat_addr)
    on_row = sum(1 for a,x,y,z in entities if project(matrix,(x,y,z),SW,SH)[2])
    on_col = sum(1 for a,x,y,z in entities if project_col(matrix,(x,y,z),SW,SH)[2])
    print(f"[*] Row-major: {on_row} on-screen, Col-major: {on_col} on-screen", flush=True)
    if on_col > on_row:
        use_col = True
        print("[*] Using COLUMN-MAJOR projection", flush=True)
    else:
        print("[*] Using ROW-MAJOR projection", flush=True)
    
    proj_fn = project_col if use_col else project
    
    for frame in range(600):  # ~30 seconds at 20fps
        try:
            root.update()
        except:
            break
        
        canvas.delete("all")
        
        # Re-read matrix
        try:
            matrix = read_matrix(pm, mat_addr)
        except:
            break
        
        # Status
        canvas.create_text(10, 15, text=f"DIAG ESP | {len(entity_addrs)} entities | frame {frame}",
                          fill='#00ff00', font=('Arial', 14, 'bold'), anchor='w')
        
        # Read and draw entities
        drawn = 0
        for addr in entity_addrs:
            try:
                raw = pm.read_bytes(addr, 12)
                x, y, z = struct.unpack("3f", raw)
            except:
                continue
            
            if not (-1500 < x < 1500 and -500 < y < 500 and -1500 < z < 1500):
                continue
            
            sx, sy, on = proj_fn(matrix, (x, y, z), SW, SH)
            if not on:
                continue
            
            # Draw box + label
            bw, bh = 50, 90
            canvas.create_rectangle(sx-bw//2, sy-bh, sx+bw//2, sy,
                                   outline='#00ff00', width=2)
            canvas.create_text(sx, sy-bh-5,
                              text=f"({x:.0f},{y:.0f},{z:.0f})",
                              fill='#ffff00', font=('Arial', 9), anchor='s')
            # Snapline
            canvas.create_line(SW//2, SH, sx, sy, fill='#ffff00', width=1)
            drawn += 1
        
        canvas.create_text(10, 35, text=f"Drawing {drawn} on-screen",
                          fill='#ff8800', font=('Arial', 12, 'bold'), anchor='w')
        
        root.update_idletasks()
        time.sleep(0.05)
    
    root.destroy()
    print("Done.", flush=True)

if __name__ == "__main__":
    main()
