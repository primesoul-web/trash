# overlay_demo.py  —  standalone, no game, no admin, no memory reading
# Teaches: transparent click-through top-most window + color-key transparency.
# pip install pygame pywin32
import pygame, win32gui, win32con, win32api

pygame.init()
W, H = win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1)  # full screen
screen = pygame.display.set_mode((W, H), pygame.NOFRAME)
hwnd = pygame.display.get_wm_info()["window"]

# The four flags, each solving one problem:
ex = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
ex |= 0x00080000  # WS_EX_LAYERED     -> allows transparency
ex |= 0x00000020  # WS_EX_TRANSPARENT -> mouse clicks pass through
ex |= 0x00000008  # WS_EX_TOPMOST     -> stays above other windows
ex |= 0x08000000  # WS_EX_NOACTIVATE  -> never steals keyboard focus
win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, ex)
win32gui.SetLayeredWindowAttributes(hwnd, win32api.RGB(0, 0, 0), 255, 0x1)  # black = invisible
win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, W, H,
                      win32con.SWP_NOACTIVATE | win32con.SWP_SHOWWINDOW)

font = pygame.font.SysFont("consolas", 16, bold=True)
running = True
while running:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            running = False

    mx, my = pygame.mouse.get_pos()
    screen.fill((0, 0, 0))                       # black -> fully transparent
    pygame.draw.rect(screen, (0, 255, 120), (mx - 40, my - 60, 80, 120), 2)  # visible box
    pygame.draw.line(screen, (255, 220, 0), (W // 2, H), (mx, my), 1)        # snapline
    t = font.render("ESC to quit", True, (255, 255, 255))
    screen.blit(t, (10, 10))
    pygame.display.flip()
    pygame.time.Clock().tick(60)
pygame.quit()