# scan_entities_fast.py
import pymem
import struct

def scan():
    try:
        pm = pymem.Pymem("CombatMaster.exe")
    except Exception as e:
        print(f"Error: {e}")
        return
        
    print("Fast scanning committed private read/write memory...")
    
    import ctypes
    from ctypes import wintypes
    
    class MEMORY_BASIC_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BaseAddress", ctypes.c_void_p),
            ("AllocationBase", ctypes.c_void_p),
            ("AllocationProtect", wintypes.DWORD),
            ("PartitionId", wintypes.WORD),
            ("RegionSize", ctypes.c_size_t),
            ("State", wintypes.DWORD),
            ("Protect", wintypes.DWORD),
            ("Type", wintypes.DWORD)
        ]
        
    kernel32 = ctypes.windll.kernel32
    VirtualQueryEx = kernel32.VirtualQueryEx
    handle = pm.process_handle
    address = 0
    mbi = MEMORY_BASIC_INFORMATION()
    
    # We target memory region: MEM_COMMIT (0x1000) and PAGE_READWRITE (0x04)
    # And we filter for type MEM_PRIVATE (0x20000) where typical dynamic heap objects reside.
    # This avoids scanning shared code assemblies and speeds up scan times.
    
    candidates = []
    while VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        if mbi.State == 0x1000 and mbi.Protect == 0x04 and mbi.Type == 0x20000:
            size = mbi.RegionSize
            # Filter regions: heap arrays or structures usually have sizes > 32KB and < 4MB
            if 32 * 1024 <= size <= 4 * 1024 * 1024:
                try:
                    chunk = pm.read_bytes(address, size)
                    float_len = size // 4
                    floats = struct.unpack(f"{float_len}f", chunk[:float_len*4])
                    
                    # Search pattern: look for consecutive coordinates X, Y, Z
                    # within typical map layout bounds
                    for i in range(0, len(floats) - 8, 4): # step by 4 (typical float structure padding alignment)
                        x, y, z = floats[i], floats[i+1], floats[i+2]
                        if -250.0 < x < 250.0 and -10.0 < y < 80.0 and -250.0 < z < 250.0:
                            # Health value validation check (100) nearby
                            for offset in range(-32, 64, 4):
                                idx = i + offset // 4
                                if 0 <= idx < len(floats):
                                    # Interpret as raw bytes to check if it's an int equal to 100
                                    val_bytes = chunk[idx*4 : idx*4+4]
                                    if len(val_bytes) == 4:
                                        val = int.from_bytes(val_bytes, byteorder='little')
                                        if val == 100:
                                            cand_addr = address + i * 4
                                            print(f"Match: Pos={x:.2f},{y:.2f},{z:.2f} | HP 100 at offset {offset} | Addr: {hex(cand_addr)}")
                                            candidates.append(cand_addr)
                                            break
                            if len(candidates) >= 15:
                                return
                except:
                    pass
        address += mbi.RegionSize

if __name__ == "__main__":
    scan()
