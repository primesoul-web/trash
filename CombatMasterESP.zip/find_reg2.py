import winreg

# Search ALL keys under HKCU\Software for any with "Screenmanager" or "Fullscreen" values
key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software")
i = 0
all_companies = []
while True:
    try:
        all_companies.append(winreg.EnumKey(key, i))
        i += 1
    except OSError:
        break
key.Close()

print(f"Total companies: {len(all_companies)}")

for company in all_companies:
    try:
        ck = winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf"Software\{company}")
        j = 0
        products = []
        while True:
            try:
                products.append(winreg.EnumKey(ck, j))
                j += 1
            except OSError:
                break
        ck.Close()
        
        for product in products:
            try:
                pk = winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf"Software\{company}\{product}")
                k = 0
                found_screen = False
                vals = []
                while True:
                    try:
                        vname, vdata, vtype = winreg.EnumValue(pk, k)
                        if 'screenmanager' in vname.lower() or 'fullscreen' in vname.lower():
                            vals.append((vname, vdata, vtype))
                            found_screen = True
                        k += 1
                    except OSError:
                        break
                pk.Close()
                if found_screen:
                    print(f"\n=== HKCU\\Software\\{company}\\{product} ===")
                    for vname, vdata, vtype in vals:
                        print(f"  {vname} = {vdata} (type={vtype})")
            except Exception:
                pass
    except Exception:
        pass
