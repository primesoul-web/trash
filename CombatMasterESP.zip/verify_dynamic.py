# verify_dynamic.py
import pymem
import time

def verify():
    pm = pymem.Pymem("CombatMaster.exe")
    # Addresses found:
    # 0xda8bb45154
    # 0xda8bb47110
    # 0xda8bb587f4
    # 0xda8bb59fb0
    # 0xda8bb5a7b0
    addrs = [0xda8bb45154, 0xda8bb47110, 0xda8bb587f4, 0xda8bb59fb0, 0xda8bb5a7b0]
    
    print("Monitoring candidate matrices for updates (rotate/move camera in-game)...")
    last_matrices = [None] * len(addrs)
    for step in range(15):
        print(f"Step {step+1}:")
        for idx, addr in enumerate(addrs):
            try:
                m = [pm.read_float(addr + i*4) for i in range(16)]
                # Check if it has changed from the last read
                changed = "STATIC"
                if last_matrices[idx] is not None:
                    if last_matrices[idx] != m:
                        changed = "DYNAMIC (UPDATED)"
                last_matrices[idx] = m
                print(f"  {hex(addr)}: {changed} - Row 0: {[round(x,3) for x in m[:4]]}")
            except Exception as e:
                print(f"  {hex(addr)}: Error: {e}")
        print("-" * 50)
        time.sleep(1)

if __name__ == "__main__":
    verify()
