# test_tkinter_overlay.py - Tests overlay using tkinter (native Win transparency)
import tkinter as tk
import ctypes
import time

# Get screen size
user32 = ctypes.windll.user32
user32.SetProcessDPIAware()
SW = user32.GetSystemMetrics(0)
SH = user32.GetSystemMetrics(1)
print(f"Screen: {SW}x{SH}")

root = tk.Tk()
root.title("ESP")
root.geometry(f"{SW}x{SH}+0+0")
root.overrideredirect(True)          # No title bar / border
root.wm_attributes("-topmost", True) # Always on top
root.wm_attributes("-transparentcolor", "#010101")  # This exact color = transparent
root.config(bg='#010101')            # Background = transparent

canvas = tk.Canvas(root, width=SW, height=SH, bg='#010101',
                   highlightthickness=0, bd=0)
canvas.pack()

# Draw very obvious test shapes
cx, cy = SW // 2, SH // 2

# Red border
canvas.create_rectangle(10, 10, SW-10, SH-10, outline='red', width=6)

# Green crosshair
canvas.create_line(cx-200, cy, cx+200, cy, fill='lime', width=4)
canvas.create_line(cx, cy-200, cx, cy+200, fill='lime', width=4)
canvas.create_oval(cx-60, cy-60, cx+60, cy+60, outline='lime', width=3)

# Yellow text
canvas.create_text(cx, 80, text="ESP OVERLAY ACTIVE", fill='yellow',
                   font=('Arial', 48, 'bold'))

# Green test boxes
for i in range(5):
    x = 150 + i * 300
    canvas.create_rectangle(x, 300, x+80, 440, outline='lime', width=3)
    canvas.create_rectangle(x, 285, x+80, 295, fill='red', outline='red')

print("Overlay displayed! You should see shapes on screen.")
print("Window stays for 20 seconds...")

# Keep refreshing topmost status
def keep_on_top():
    root.lift()
    root.wm_attributes("-topmost", True)
    # Also use Win32 API to force it
    hwnd = int(root.frame(), 16)
    ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
    root.after(500, keep_on_top)

keep_on_top()

# Auto-close after 20 seconds
root.after(20000, root.destroy)
root.mainloop()
print("Test done.")
