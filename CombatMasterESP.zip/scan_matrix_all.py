# scan_matrix_all.py
import pymem
import struct
import numpy as np

def scan_all():
    print("Attaching to CombatMaster.exe...")
    try:
        pm = pymem.Pymem("CombatMaster.exe")
    except Exception as e:
        print(f"Error: {e}")
        return
        
    print("Enumerating memory regions...")
    # Find all read-write or readable regions of memory
    # We will search the entire process memory space for the view matrix
    # The view matrix is frequently modified, has specific camera properties.
    # Unity Camera ViewMatrix signature check:
    # Often, index 11 is 1.0 or -1.0, index 15 is 0.0 or 1.0.
    # The elements [0], [5], [10] are often diagonal scaling factors.
    # Let's search across all committed RAM.
    
    import ctypes
    from ctypes import wintypes
    
    class MEMORY_BASIC_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BaseAddress", ctypes.c_void_p),
            ("AllocationBase", ctypes.c_void_p),
            ("AllocationProtect", wintypes.DWORD),
            ("PartitionId", wintypes.WORD),
            ("RegionSize", ctypes.c_size_t),
            ("State", wintypes.DWORD),
            ("Protect", wintypes.DWORD),
            ("Type", wintypes.DWORD)
        ]
        
    kernel32 = ctypes.windll.kernel32
    VirtualQueryEx = kernel32.VirtualQueryEx
    VirtualQueryEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(MEMORY_BASIC_INFORMATION), ctypes.c_size_t]
    VirtualQueryEx.restype = ctypes.c_size_t
    
    handle = pm.process_handle
    address = 0
    mbi = MEMORY_BASIC_INFORMATION()
    
    candidates = []
    print("Scanning process memory regions...")
    while VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        # State: MEM_COMMIT = 0x1000
        # Protect: Page can be read (PAGE_READONLY=0x02, PAGE_READWRITE=0x04, PAGE_WRITECOPY=0x08, PAGE_EXECUTE_READ=0x20, PAGE_EXECUTE_READWRITE=0x40)
        if mbi.State == 0x1000 and (mbi.Protect & 0xEC):
            size = mbi.RegionSize
            if size > 1024:
                try:
                    chunk = pm.read_bytes(address, size)
                    # Scan chunk for matrix
                    float_len = size // 4
                    floats = struct.unpack(f"{float_len}f", chunk[:float_len*4])
                    for i in range(len(floats) - 16):
                        m = floats[i:i+16]
                        # Projection matrix check:
                        # Index 11 is -1 or 1 (usually -1 for standard OpenGL/Unity projection)
                        # Index 15 is 0
                        # Let's also check if the diagonal looks like reasonable scaling
                        if abs(m[11] - (-1.0)) < 0.0001 and abs(m[15]) < 0.0001:
                            # Let's check scaling factors
                            if 0.1 < abs(m[0]) < 10.0 and 0.1 < abs(m[5]) < 10.0:
                                cand_addr = address + i * 4
                                print(f"Found match at: {hex(cand_addr)}")
                                print(f"Matrix: {np.array(m).reshape(4,4)}")
                                candidates.append(cand_addr)
                                if len(candidates) >= 10:
                                    return
                except:
                    pass
        address += mbi.RegionSize

if __name__ == "__main__":
    scan_all()
