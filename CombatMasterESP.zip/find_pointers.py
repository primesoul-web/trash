# find_pointers.py
import pymem
import struct

def find_pointers():
    print("Attaching to CombatMaster.exe...")
    try:
        pm = pymem.Pymem("CombatMaster.exe")
    except Exception as e:
        print(f"Error: {e}")
        return

    import ctypes
    from ctypes import wintypes
    
    class MEMORY_BASIC_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BaseAddress", ctypes.c_void_p),
            ("AllocationBase", ctypes.c_void_p),
            ("AllocationProtect", wintypes.DWORD),
            ("PartitionId", wintypes.WORD),
            ("RegionSize", ctypes.c_size_t),
            ("State", wintypes.DWORD),
            ("Protect", wintypes.DWORD),
            ("Type", wintypes.DWORD)
        ]
        
    kernel32 = ctypes.windll.kernel32
    VirtualQueryEx = kernel32.VirtualQueryEx
    handle = pm.process_handle
    
    # We want to find pointers in memory pointing to the active view matrix (0xda8bb5a7b0 or nearby)
    # and pointers pointing to player entities (0xda8bb764d0 or nearby)
    target_matrix = 0xda8bb5a7b0
    target_player = 0xda8bb764d0
    
    print(f"Scanning process memory for 64-bit pointers pointing near:")
    print(f"  Matrix: {hex(target_matrix)}")
    print(f"  Player: {hex(target_player)}")

    address = 0
    mbi = MEMORY_BASIC_INFORMATION()
    while VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        if mbi.State == 0x1000 and (mbi.Protect & 0xEC): # Committed, readable
            size = mbi.RegionSize
            try:
                chunk = pm.read_bytes(address, size)
                # Read 64-bit integers
                ptr_count = size // 8
                ptrs = struct.unpack(f"{ptr_count}Q", chunk[:ptr_count*8])
                for idx, val in enumerate(ptrs):
                    # Check if val points within a 0x1000 byte range of the target matrix or player coords
                    if abs(val - target_matrix) < 0x1000:
                        ptr_addr = address + idx * 8
                        print(f"Matrix pointer candidate found at {hex(ptr_addr)} -> value: {hex(val)}")
                    if abs(val - target_player) < 0x1000:
                        ptr_addr = address + idx * 8
                        print(f"Player pointer candidate found at {hex(ptr_addr)} -> value: {hex(val)}")
            except:
                pass
        address += mbi.RegionSize

if __name__ == "__main__":
    find_pointers()
