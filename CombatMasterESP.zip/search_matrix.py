# search_matrix.py
import pymem
import pymem.process
import struct
import numpy as np

def find_matrix():
    print("Attaching to CombatMaster.exe...")
    try:
        pm = pymem.Pymem("CombatMaster.exe")
    except Exception as e:
        print(f"Error attaching: {e}")
        return

    module = pymem.process.module_from_name(pm.process_handle, "GameAssembly.dll")
    base = module.lpBaseOfDll
    size = module.SizeOfImage
    print(f"GameAssembly.dll Base: {hex(base)}, Size: {size} bytes")

    print("Scanning memory for projection/view matrix patterns...")
    # View matrix values are floats. A projection matrix typically has specific structures:
    # Row 3 (0-indexed) is often [0, 0, -1, 0] or similar for perspective division, or clip space Z/W ratios.
    # We will search the GameAssembly.dll region for float blocks.
    
    # Read entire module memory into python to scan fast
    try:
        data = pm.read_bytes(base, size)
    except Exception as e:
        print(f"Error reading module bytes: {e}")
        return

    print("Bytes read. Searching for float patterns...")
    # Look for floats in the buffer
    # Standard view matrix floats range from -1.0 to 1.0 mostly, except position translations.
    # Let's search for potential view matrix addresses.
    # Unity standard Camera.main view matrix or active camera matrix.
    # We'll look for blocks of 16 floats.
    float_count = size // 4
    floats = struct.unpack(f"{float_count}f", data[:float_count*4])
    
    # Let's search for common projection matrix values:
    # Typical perspective matrix has element [3][2] (idx 11 or 14 depending on row/col major) as -1.0 or 1.0, and [3][3] (idx 15) as 0.0.
    matches = []
    for i in range(len(floats) - 16):
        # Let's check if it matches a Unity Camera matrix signature:
        # e.g., index 3, 7, 11 are often 0, 0, -1/1 (if column major)
        # or index 12, 13, 14 are 0, 0, -1/1 (if row major)
        m = floats[i:i+16]
        # Quick heuristic for a projection matrix:
        # matrix[3] is usually 0, 0, -1 (or 1), 0  or  matrix[12..15] is 0, 0, -1, 0
        if (abs(m[11] - (-1.0)) < 0.01 or abs(m[11] - 1.0) < 0.01) and abs(m[15]) < 0.01:
            addr = base + i * 4
            print(f"Found candidate matrix at: {hex(addr)}")
            print(f"Matrix: {np.array(m).reshape(4,4)}")
            matches.append(addr)
            if len(matches) >= 5:
                break
                
    if not matches:
        print("No matches found in GameAssembly.dll. Let's write a wider scanner script next.")

if __name__ == "__main__":
    find_matrix()
