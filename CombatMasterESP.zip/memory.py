# memory.py
import pymem
import pymem.process
import struct
from typing import List, Tuple

class ProcessMemory:
    def __init__(self, exe_name: str):
        self.pm = pymem.Pymem(exe_name)
        self.base = pymem.process.module_from_name(self.pm.process_handle, exe_name).lpBaseOfDll

    def read(self, address: int, fmt: str):
        size = struct.calcsize(fmt)
        data = self.pm.read_bytes(address, size)
        return struct.unpack(fmt, data)[0]

    def read_float(self, address: int) -> float:
        return self.read(address, "f")

    def read_int(self, address: int) -> int:
        return self.read(address, "i")

    def read_uint(self, address: int) -> int:
        return self.read(address, "I")

    def read_vec3(self, address: int) -> Tuple[float, float, float]:
        x = self.read_float(address)
        y = self.read_float(address + 0x4)
        z = self.read_float(address + 0x8)
        return (x, y, z)

    def get_entity_list(self, list_base: int, count_offset: int,
                        entity_ptr_offset: int) -> List[int]:
        count = self.read_int(list_base + count_offset)
        ptr = self.read_uint(list_base + entity_ptr_offset)
        entities = []
        for i in range(count):
            ent_addr = self.read_uint(ptr + i * 0x8)
            entities.append(ent_addr)
        return entities

    def get_position(self, entity_addr: int, pos_offset: int) -> Tuple[float, float, float]:
        return self.read_vec3(entity_addr + pos_offset)

    def get_health(self, entity_addr: int, hp_offset: int) -> int:
        return self.read_int(entity_addr + hp_offset)

    def get_team(self, entity_addr: int, team_offset: int) -> int:
        return self.read_int(entity_addr + team_offset)

    def is_alive(self, entity_addr: int, state_offset: int) -> bool:
        state = self.read_int(entity_addr + state_offset)
        return state == 0
