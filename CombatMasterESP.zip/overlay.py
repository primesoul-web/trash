# overlay.py – Tkinter-based transparent overlay (works with admin games)
import os
import ctypes
import tkinter as tk

def get_screen_size():
    user32 = ctypes.windll.user32
    user32.SetProcessDPIAware()
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)


class Overlay:
    TRANSPARENT = '#010101'   # this exact color = see-through

    def __init__(self):
        sw, sh = get_screen_size()
        self.width  = sw
        self.height = sh
        print(f"[+] Overlay size: {sw}x{sh}", flush=True)

        self.root = tk.Tk()
        self.root.title("ESP")
        self.root.geometry(f"{sw}x{sh}+0+0")
        self.root.overrideredirect(True)
        self.root.wm_attributes("-topmost", True)
        self.root.wm_attributes("-transparentcolor", self.TRANSPARENT)
        self.root.config(bg=self.TRANSPARENT)

        self.canvas = tk.Canvas(
            self.root, width=sw, height=sh,
            bg=self.TRANSPARENT, highlightthickness=0, bd=0)
        self.canvas.pack()

        # Keep window on top periodically
        self._keep_on_top()

    def _keep_on_top(self):
        try:
            self.root.lift()
            self.root.wm_attributes("-topmost", True)
        except Exception:
            pass
        self.root.after(1000, self._keep_on_top)

    # ── Drawing helpers ──────────────────────────────────────────────────
    def clear(self):
        self.canvas.delete("all")

    def draw_box(self, x, y, w, h, color='#00ff00'):
        self.canvas.create_rectangle(
            int(x), int(y), int(x+w), int(y+h),
            outline=color, width=2)

    def draw_line(self, start, end, color='#ffff00'):
        self.canvas.create_line(
            int(start[0]), int(start[1]),
            int(end[0]), int(end[1]),
            fill=color, width=1)

    def draw_health(self, x, y, health, max_health=100):
        bar_w = 40
        ratio = max(0.0, min(1.0, health / max_health))
        fill = int(bar_w * ratio)
        # Red background
        self.canvas.create_rectangle(
            int(x), int(y), int(x + bar_w), int(y + 6),
            fill='#cc0000', outline='#cc0000')
        # Green fill
        if fill > 0:
            g = int(255 * ratio)
            r = 255 - g
            color = f'#{r:02x}{g:02x}00'
            self.canvas.create_rectangle(
                int(x), int(y), int(x + fill), int(y + 6),
                fill=color, outline=color)

    def draw_text(self, x, y, text, color='#ffffff'):
        self.canvas.create_text(
            int(x), int(y), text=text, fill=color,
            font=('Arial', 12, 'bold'), anchor='nw')

    def present(self):
        self.root.update_idletasks()
        self.root.update()

    def pump_events(self):
        """Check for window close events. Returns False if should quit."""
        try:
            self.root.update()
            return True
        except tk.TclError:
            return False
