import winreg

REG_PATH = r"Software\AlfaBravoInc\Combat Master"

# Set fullscreen mode to 3 = Windowed
key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_SET_VALUE)
winreg.SetValueEx(key, "Screenmanager Fullscreen mode_h3630240806", 0, winreg.REG_DWORD, 3)
winreg.SetValueEx(key, "Screenmanager Fullscreen mode Default_h401710285", 0, winreg.REG_DWORD, 3)
winreg.SetValueEx(key, "Screenmanager Resolution Width_h182942802", 0, winreg.REG_DWORD, 1920)
winreg.SetValueEx(key, "Screenmanager Resolution Height_h2627697771", 0, winreg.REG_DWORD, 1080)
key.Close()

print("Registry updated:")
print("  Fullscreen mode -> 3 (Windowed)")
print("  Resolution -> 1920x1080")
print()
print("Now CLOSE the game completely and relaunch from Steam.")
print("The game should start in a windowed 1920x1080 window.")
