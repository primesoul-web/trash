# test_dynamic_entities.py
import pymem
import time
import struct

def test():
    pm = pymem.Pymem("CombatMaster.exe")
    # Addresses near candidates found
    # Let's monitor 0xda8bb8b8f0, 0xda8bbdc1d0 for coordinate changes when moving
    addrs = [0xda8bb8b8f0, 0xda8bbdc1d0]
    
    print("Monitoring candidates. Move in-game to see which values update dynamically...")
    for step in range(15):
        print(f"Step {step+1}:")
        for addr in addrs:
            try:
                x = pm.read_float(addr)
                y = pm.read_float(addr+4)
                z = pm.read_float(addr+8)
                print(f"  {hex(addr)}: Pos: {x:.3f}, {y:.3f}, {z:.3f}")
            except Exception as e:
                print(f"  {hex(addr)}: Error: {e}")
        print("-" * 50)
        time.sleep(1)

if __name__ == "__main__":
    test()
