@echo off
echo ============================================
echo   Running ESP overlay as Administrator...
echo ============================================
cd /d D:\CombatMasterESP
python test_tkinter_overlay.py
pause
