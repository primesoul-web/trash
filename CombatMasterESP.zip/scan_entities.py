# scan_entities.py
import pymem
import struct

def scan():
    pm = pymem.Pymem("CombatMaster.exe")
    print("Scanning player list and entity structures...")
    # Typically, health is a 4-byte int (like 100).
    # Since we are in bot match/private match, let's scan for values around 100
    # and check if they are near other players' positions.
    # Alternatively, we can search for game object pointers.
    # Let's inspect memory region properties and look for structured layouts.
    
    # We will search the heap / committed memory for potential player entities.
    # Player position floats are usually nearby (e.g. X, Y, Z coordinates).
    # Let's print our own position first if we can identify it.
    # A quick way to find player coordinates: scan for float values representing X, Y, Z.
    
    import ctypes
    from ctypes import wintypes
    
    class MEMORY_BASIC_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BaseAddress", ctypes.c_void_p),
            ("AllocationBase", ctypes.c_void_p),
            ("AllocationProtect", wintypes.DWORD),
            ("PartitionId", wintypes.WORD),
            ("RegionSize", ctypes.c_size_t),
            ("State", wintypes.DWORD),
            ("Protect", wintypes.DWORD),
            ("Type", wintypes.DWORD)
        ]
        
    kernel32 = ctypes.windll.kernel32
    VirtualQueryEx = kernel32.VirtualQueryEx
    handle = pm.process_handle
    address = 0
    mbi = MEMORY_BASIC_INFORMATION()
    
    # Let's find regions that might hold entities (typically MEM_COMMIT and PAGE_READWRITE)
    print("Scanning read/write memory chunks for positions and health...")
    while VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)) > 0:
        if mbi.State == 0x1000 and mbi.Protect == 0x04: # MEM_COMMIT & PAGE_READWRITE
            size = mbi.RegionSize
            if 0x10000 <= size <= 0x1000000: # 64KB to 16MB (typical heap chunks)
                try:
                    chunk = pm.read_bytes(address, size)
                    # Search for consecutive floats (like position X, Y, Z)
                    # Let's check for floats that vary but are within typical map bounds (e.g., -500.0 to 500.0)
                    # and have a height coordinate (Y) between -50.0 and 200.0.
                    float_len = size // 4
                    floats = struct.unpack(f"{float_len}f", chunk[:float_len*4])
                    for i in range(len(floats) - 3):
                        x, y, z = floats[i], floats[i+1], floats[i+2]
                        # Check typical spatial cluster
                        if -300.0 < x < 300.0 and -20.0 < y < 100.0 and -300.0 < z < 300.0:
                            # Let's verify if there is a nearby health-like value (e.g. 100) within 0x100 bytes
                            # We check 4-byte integers in the same block
                            int_offset = i * 4
                            # Look forward/backward for a health value of 100
                            # A Player structure usually has health near position
                            for offset in range(-64, 64, 4):
                                if 0 <= int_offset + offset < size - 4:
                                    val = int.from_bytes(chunk[int_offset+offset : int_offset+offset+4], byteorder='little')
                                    if val == 100:
                                        ent_addr = address + int_offset
                                        print(f"Candidate Entity position: {x:.2f}, {y:.2f}, {z:.2f} at: {hex(ent_addr)}")
                                        print(f"  Health value 100 found at offset: {hex(offset)}")
                except:
                    pass
        address += mbi.RegionSize

if __name__ == "__main__":
    scan()
