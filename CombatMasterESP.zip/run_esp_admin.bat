@echo off
echo ============================================
echo   Combat Master ESP Overlay (Admin)
echo ============================================
cd /d D:\CombatMasterESP
python main.py
pause
