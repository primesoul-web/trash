# test_candidates.py
import pymem
import time

def test():
    pm = pymem.Pymem("CombatMaster.exe")
    # Dynamic coordinate matches detected in active game space:
    # 0xda8bb764d0 and 0xda8bb76530 look like real world coordinates:
    # Pos = 115.92, -1.13, 53.89
    # Let's inspect these candidates dynamically.
    addrs = [0xda8bb764d0, 0xda8bb76530]
    
    print("Monitoring candidates. Move in-game to verify coordinates update dynamically:")
    for step in range(20):
        print(f"[{step+1:02d}]")
        for addr in addrs:
            try:
                x = pm.read_float(addr)
                y = pm.read_float(addr+4)
                z = pm.read_float(addr+8)
                print(f"  {hex(addr)}: Pos={x:.3f}, {y:.3f}, {z:.3f}")
            except Exception as e:
                print(f"  {hex(addr)}: Error: {e}")
        print("-" * 50)
        time.sleep(0.5)

if __name__ == "__main__":
    test()
