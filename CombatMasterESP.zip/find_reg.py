import winreg

# Search for Combat Master / Unity game keys in HKCU\Software
key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software")
i = 0
matches = []
while True:
    try:
        name = winreg.EnumKey(key, i)
        low = name.lower()
        if any(kw in low for kw in ['combat', 'alfatech', 'jeek', 'master', 'unity']):
            matches.append(name)
        i += 1
    except OSError:
        break
key.Close()

print("Matching registry keys under HKCU\\Software:")
for m in matches:
    print(f"  {m}")
    try:
        sub = winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf"Software\{m}")
        j = 0
        while True:
            try:
                subname = winreg.EnumKey(sub, j)
                print(f"    \\{subname}")
                # Check for Screenmanager values
                try:
                    subsub = winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf"Software\{m}\{subname}")
                    k = 0
                    while True:
                        try:
                            vname, vdata, vtype = winreg.EnumValue(subsub, k)
                            if 'screen' in vname.lower() or 'resolution' in vname.lower() or 'fullscreen' in vname.lower():
                                print(f"      {vname} = {vdata} (type={vtype})")
                            k += 1
                        except OSError:
                            break
                    subsub.Close()
                except Exception:
                    pass
                j += 1
            except OSError:
                break
        sub.Close()
    except Exception:
        pass

# Also check direct values under each match
for m in matches:
    try:
        sub = winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf"Software\{m}")
        k = 0
        print(f"\nValues directly under HKCU\\Software\\{m}:")
        while True:
            try:
                vname, vdata, vtype = winreg.EnumValue(sub, k)
                if 'screen' in vname.lower() or 'resolution' in vname.lower() or 'fullscreen' in vname.lower():
                    print(f"  {vname} = {vdata} (type={vtype})")
                k += 1
            except OSError:
                break
        sub.Close()
    except Exception:
        pass
