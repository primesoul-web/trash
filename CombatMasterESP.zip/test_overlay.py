# test_overlay.py – Tests if the overlay window actually appears on screen
# Run this WITH the game running. You should see a red cross on screen.
import pygame
import win32gui
import win32con
import win32api
import ctypes
import time

def find_game_window():
    """Find the game window handle and its position/size."""
    result = {}
    def callback(hwnd, extra):
        title = win32gui.GetWindowText(hwnd)
        if "Combat Master" in title or "CombatMaster" in title:
            rect = win32gui.GetWindowRect(hwnd)
            result['hwnd']  = hwnd
            result['rect']  = rect
            result['title'] = title
    win32gui.EnumWindows(callback, None)
    return result

game = find_game_window()
print("Game windows found:", game)

# Use game dimensions if found, else fullscreen
if game:
    rect  = game['rect']
    x, y  = rect[0], rect[1]
    w, h  = rect[2] - rect[0], rect[3] - rect[1]
    print(f"Game at ({x},{y}) size {w}x{h}")
else:
    x, y, w, h = 0, 0, 1920, 1080
    print("Game window not found, using 1920x1080 at (0,0)")

import os
os.environ['SDL_VIDEO_WINDOW_POS'] = f"{x},{y}"

pygame.init()
screen = pygame.display.set_mode((w, h), pygame.NOFRAME)
pygame.display.set_caption("ESP Test")

hwnd = pygame.display.get_wm_info()["window"]

# Apply layered/transparent/topmost styles
ex_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
ex_style |= (win32con.WS_EX_LAYERED |
             win32con.WS_EX_TRANSPARENT |
             win32con.WS_EX_TOPMOST |
             win32con.WS_EX_NOACTIVATE)
win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, ex_style)
win32gui.SetLayeredWindowAttributes(hwnd, win32api.RGB(0, 0, 0), 255, win32con.LWA_COLORKEY)

# Force position on top
SWP_NOMOVE    = 0x0002
SWP_NOSIZE    = 0x0001
SWP_SHOWWINDOW = 0x0040
HWND_TOPMOST  = -1
ctypes.windll.user32.SetWindowPos(hwnd, HWND_TOPMOST, x, y, w, h, SWP_SHOWWINDOW)

print(f"Overlay hwnd={hwnd}, positioned at ({x},{y}) size {w}x{h}")
print("You should see a RED CROSS on screen for 10 seconds...")

start = time.time()
while time.time() - start < 10:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break

    screen.fill((0, 0, 0))  # black = transparent (color key)

    # Draw a very visible red cross
    cx, cy = w // 2, h // 2
    pygame.draw.line(screen, (255, 0, 0), (cx - 100, cy), (cx + 100, cy), 5)
    pygame.draw.line(screen, (255, 0, 0), (cx, cy - 100), (cx, cy + 100), 5)
    pygame.draw.rect(screen, (0, 255, 0), (cx - 50, cy - 75, 100, 150), 3)
    pygame.draw.line(screen, (255, 255, 0), (cx, h), (cx, cy), 2)

    pygame.display.flip()
    time.sleep(0.016)

pygame.quit()
print("Test done.")
