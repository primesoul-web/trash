# angles.py
import math
from typing import Tuple

def vector_to_angles(forward: Tuple[float, float, float]) -> Tuple[float, float]:
    x, y, z = forward
    yaw = math.degrees(math.atan2(y, x))
    hyp = math.sqrt(x * x + y * y)
    pitch = math.degrees(math.atan2(-z, hyp))
    return pitch, yaw

def smooth_angle(prev: float, target: float, factor: float = 0.2) -> float:
    diff = (target - prev + 180) % 360 - 180
    return prev + diff * factor
