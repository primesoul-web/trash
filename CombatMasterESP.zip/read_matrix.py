# read_matrix.py
import pymem
import time

def read():
    pm = pymem.Pymem("CombatMaster.exe")
    addr1 = 0x7ffa46286f98
    addr2 = 0x7ffa46287098
    print("Reading matrices dynamically (move around in-game to see changes):")
    for _ in range(10):
        # Read 16 floats from candidate addresses
        m1 = [pm.read_float(addr1 + i*4) for i in range(16)]
        m2 = [pm.read_float(addr2 + i*4) for i in range(16)]
        print(f"Candidate 1: {[round(x, 2) for x in m1[:4]]} ... {[round(x, 2) for x in m1[12:]]}")
        print(f"Candidate 2: {[round(x, 2) for x in m2[:4]]} ... {[round(x, 2) for x in m2[12:]]}")
        print("-" * 50)
        time.sleep(1)

if __name__ == "__main__":
    read()
