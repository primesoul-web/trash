# verify_matrix_updates.py
import pymem
import time

def verify_matrix():
    pm = pymem.Pymem("CombatMaster.exe")
    addr = 0xda8bb5a7b0
    print(f"Monitoring address {hex(addr)} continuously. Please rotate/move your camera in game now...")
    
    last_m = None
    for i in range(30):
        try:
            m = [pm.read_float(addr + offset*4) for offset in range(16)]
            if last_m is not None:
                diff = sum(abs(a - b) for a, b in zip(m, last_m))
                if diff > 0.001:
                    print(f"[{i:02d}] Matrix changed! Diff: {diff:.4f}")
                    # Print first 2 rows of matrix
                    print(f"      Row 0: {[round(x, 3) for x in m[0:4]]}")
                    print(f"      Row 1: {[round(x, 3) for x in m[4:8]]}")
                    print(f"      Row 2: {[round(x, 3) for x in m[8:12]]}")
                    print(f"      Row 3: {[round(x, 3) for x in m[12:16]]}")
            last_m = m
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(0.5)

if __name__ == "__main__":
    verify_matrix()
