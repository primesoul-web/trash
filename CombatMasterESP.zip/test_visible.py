# test_visible.py - Draws very obvious shapes on the overlay for 20 seconds
# If you can see bright colored shapes on top of the game, the overlay works.
import os
import sys
import time
import ctypes
import pygame
import win32gui
import win32con
import win32api

# Get screen size
user32 = ctypes.windll.user32
user32.SetProcessDPIAware()
SW = user32.GetSystemMetrics(0)
SH = user32.GetSystemMetrics(1)
print(f"Screen: {SW}x{SH}")

os.environ['SDL_VIDEO_WINDOW_POS'] = "0,0"

pygame.init()
screen = pygame.display.set_mode((SW, SH), pygame.NOFRAME)
pygame.display.set_caption("TEST")
hwnd = pygame.display.get_wm_info()["window"]

# Apply overlay styles
ex = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
ex |= (win32con.WS_EX_LAYERED | win32con.WS_EX_TRANSPARENT |
       win32con.WS_EX_TOPMOST | win32con.WS_EX_NOACTIVATE)
win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, ex)
win32gui.SetLayeredWindowAttributes(hwnd, win32api.RGB(0, 0, 0), 255, win32con.LWA_COLORKEY)
ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, SW, SH, 0x0040)

print(f"Overlay hwnd={hwnd}")
print("Drawing bright shapes for 20 seconds...")
print("YOU SHOULD SEE: Red border + green crosshair + yellow text on screen")

font = pygame.font.SysFont('Arial', 48, bold=True)

start = time.time()
while time.time() - start < 20:
    for ev in pygame.event.get():
        if ev.type == pygame.QUIT:
            sys.exit()

    screen.fill((0, 0, 0))  # black = transparent

    # Draw a very thick red border around the entire screen
    pygame.draw.rect(screen, (255, 0, 0), (5, 5, SW-10, SH-10), 8)

    # Draw a bright green crosshair in the center
    cx, cy = SW // 2, SH // 2
    pygame.draw.line(screen, (0, 255, 0), (cx - 200, cy), (cx + 200, cy), 4)
    pygame.draw.line(screen, (0, 255, 0), (cx, cy - 200), (cx, cy + 200), 4)
    pygame.draw.circle(screen, (0, 255, 0), (cx, cy), 50, 3)

    # Draw bright yellow text
    txt = font.render("ESP OVERLAY ACTIVE", True, (255, 255, 0))
    screen.blit(txt, (cx - txt.get_width()//2, 60))

    # Draw some test boxes at fixed positions
    for i in range(5):
        x = 200 + i * 300
        y = 300
        pygame.draw.rect(screen, (0, 255, 0), (x, y, 80, 140), 3)
        pygame.draw.rect(screen, (255, 0, 0), (x, y - 15, 80, 10))

    pygame.display.flip()
    time.sleep(0.016)

pygame.quit()
print("Test done.")
