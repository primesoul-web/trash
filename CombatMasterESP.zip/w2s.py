# w2s.py
import numpy as np
from typing import Tuple

class WorldToScreen:
    def __init__(self, view_matrix: list):
        self.matrix = np.array(view_matrix).reshape((4, 4))

    def project(self, pos: Tuple[float, float, float], screen_width: int, screen_height: int) -> Tuple[int, int, bool]:
        vec = np.array([pos[0], pos[1], pos[2], 1.0])
        clip = self.matrix @ vec
        if clip[3] < 0.1:
            return (0, 0, False)
        ndc = clip[:3] / clip[3]
        x = int((ndc[0] + 1) * 0.5 * screen_width)
        y = int((1 - ndc[1]) * 0.5 * screen_height)
        on_screen = 0 <= x <= screen_width and 0 <= y <= screen_height
        return (x, y, on_screen)
